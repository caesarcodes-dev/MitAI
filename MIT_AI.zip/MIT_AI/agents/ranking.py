import numpy as np
import pandas as pd
from typing import List, Dict, Any
import re
from datetime import datetime
import random

class RankingAgent:
    """
    AI Agent responsible for ranking candidates based on skills, experience, and location.
    Implements bias-free scoring mechanisms.
    """
    
    def __init__(self):
        self.skill_complexity_weights = {
            # AI/ML Framework Skills (High complexity)
            'PyTorch': 0.95,
            'TensorFlow': 0.95,
            'Keras': 0.80,
            'Scikit-learn': 0.75,
            'Transformers': 0.90,
            'LangChain': 0.85,
            'MLflow': 0.80,
            
            # Computer Vision
            'OpenCV': 0.85,
            'YOLO': 0.90,
            'MediaPipe': 0.80,
            
            # NLP
            'NLTK': 0.70,
            'spaCy': 0.75,
            'Hugging Face': 0.85,
            
            # Cloud & Infrastructure
            'AWS': 0.80,
            'Azure': 0.80,
            'GCP': 0.80,
            'Docker': 0.75,
            'Kubernetes': 0.85,
            
            # Programming Languages
            'Python': 0.70,
            'R': 0.70,
            'Java': 0.65,
            'C++': 0.80,
            'JavaScript': 0.60,
            'TypeScript': 0.65,
            
            # Databases
            'SQL': 0.60,
            'MongoDB': 0.65,
            'PostgreSQL': 0.70,
            'Redis': 0.70,
            
            # Web Frameworks
            'FastAPI': 0.75,
            'Django': 0.70,
            'Flask': 0.65,
            'React': 0.70,
            'Node.js': 0.65,
            
            # Data Science
            'Pandas': 0.60,
            'NumPy': 0.60,
            'Matplotlib': 0.55,
            'Seaborn': 0.55,
            'Plotly': 0.60,
            
            # Default for unknown skills
            'default': 0.50
        }
        
        self.location_preferences = {
            'Remote': 1.0,
            'New York': 0.9,
            'San Francisco': 0.9,
            'London': 0.85,
            'Berlin': 0.8,
            'Singapore': 0.8,
            'Boston': 0.85,
            'Seattle': 0.85,
            'Toronto': 0.8,
            'Amsterdam': 0.8,
            'Any': 0.7
        }
        
        # Sample candidate database (in real scenario, this would come from CV processing)
        self.candidate_database = self._generate_sample_candidates()
    
    def _generate_sample_candidates(self) -> List[Dict]:
        """Generate sample candidate data for demonstration"""
        
        names = [
            "Alex Chen", "Sarah Johnson", "Michael Rodriguez", "Priya Patel",
            "David Kim", "Elena Volkov", "James Wilson", "Aisha Ahmed",
            "Robert Zhang", "Maria Garcia", "John Smith", "Lisa Wang",
            "Ahmed Hassan", "Jennifer Lee", "Carlos Silva", "Anna Kowalski",
            "Ryan O'Connor", "Fatima Al-Rashid", "Kevin Nguyen", "Sophie Martin"
        ]
        
        locations = list(self.location_preferences.keys())[:-1]  # Exclude 'Any'
        
        skill_sets = [
            ['Python', 'PyTorch', 'TensorFlow', 'OpenCV', 'AWS', 'Docker'],
            ['Python', 'Scikit-learn', 'Pandas', 'SQL', 'Matplotlib'],
            ['JavaScript', 'React', 'Node.js', 'MongoDB', 'Docker'],
            ['Python', 'Django', 'PostgreSQL', 'Redis', 'AWS'],
            ['Python', 'Transformers', 'NLTK', 'spaCy', 'Azure'],
            ['Python', 'TensorFlow', 'Keras', 'GCP', 'MLflow'],
            ['Python', 'LangChain', 'OpenCV', 'FastAPI', 'Docker'],
            ['Java', 'Python', 'Kubernetes', 'AWS', 'MongoDB'],
            ['Python', 'PyTorch', 'Hugging Face', 'Transformers', 'NLTK'],
            ['TypeScript', 'React', 'Node.js', 'PostgreSQL', 'Docker'],
        ]
        
        candidates = []
        for i, name in enumerate(names):
            candidate = {
                'name': name,
                'email': f"{name.lower().replace(' ', '.')}@email.com",
                'location': random.choice(locations),
                'experience': random.randint(1, 12),
                'skills': random.choice(skill_sets) + random.sample(
                    list(self.skill_complexity_weights.keys())[:15], 
                    random.randint(2, 5)
                ),
                'cv_path': f"docs/cv_{i+1}.pdf"
            }
            candidates.append(candidate)
        
        return candidates
    
    def calculate_skills_score(self, candidate_skills: List[str], required_skills: List[str], 
                             job_complexity: str = "Mid") -> float:
        """
        Calculate skills-based score considering complexity and job requirements.
        Implements bias-free skill matching.
        """
        if not required_skills:
            return 50.0
        
        # Complexity multiplier based on job level
        complexity_multipliers = {
            "Junior (0-2 years)": 0.8,
            "Mid (2-5 years)": 1.0,
            "Senior (5+ years)": 1.2,
            "Lead (8+ years)": 1.4
        }
        
        complexity_mult = complexity_multipliers.get(job_complexity, 1.0)
        
        total_score = 0
        max_possible_score = 0
        
        for skill in required_skills:
            skill_weight = self.skill_complexity_weights.get(skill, 
                                                           self.skill_complexity_weights['default'])
            max_possible_score += skill_weight * complexity_mult * 100
            
            if skill in candidate_skills:
                # Perfect match
                total_score += skill_weight * complexity_mult * 100
            else:
                # Check for related skills (fuzzy matching)
                related_score = self._calculate_related_skills_score(skill, candidate_skills)
                total_score += related_score * skill_weight * complexity_mult * 100
        
        # Normalize to 0-100 scale
        if max_possible_score > 0:
            normalized_score = (total_score / max_possible_score) * 100
        else:
            normalized_score = 0
        
        return min(normalized_score, 100.0)
    
    def _calculate_related_skills_score(self, required_skill: str, candidate_skills: List[str]) -> float:
        """Calculate score for related/similar skills"""
        
        # Define skill relationships (simplified)
        skill_relationships = {
            'PyTorch': ['TensorFlow', 'Keras', 'Deep Learning'],
            'TensorFlow': ['PyTorch', 'Keras', 'Deep Learning'],
            'React': ['Vue', 'Angular', 'JavaScript'],
            'Python': ['R', 'Julia', 'Scala'],
            'AWS': ['Azure', 'GCP', 'Cloud Computing'],
            'Docker': ['Kubernetes', 'Containerization'],
        }
        
        related_skills = skill_relationships.get(required_skill, [])
        
        for candidate_skill in candidate_skills:
            if candidate_skill in related_skills:
                return 0.7  # 70% score for related skills
            elif self._is_similar_skill(required_skill, candidate_skill):
                return 0.5  # 50% score for similar skills
        
        return 0.0
    
    def _is_similar_skill(self, skill1: str, skill2: str) -> bool:
        """Check if two skills are similar using basic text matching"""
        skill1_lower = skill1.lower()
        skill2_lower = skill2.lower()
        
        # Check for partial matches
        if len(skill1_lower) > 3 and skill1_lower in skill2_lower:
            return True
        if len(skill2_lower) > 3 and skill2_lower in skill1_lower:
            return True
        
        return False
    
    def calculate_experience_score(self, candidate_experience: int, job_level: str) -> float:
        """Calculate experience-based score"""
        
        # Define experience ranges for different job levels
        experience_ranges = {
            "Junior (0-2 years)": (0, 3),
            "Mid (2-5 years)": (2, 6),
            "Senior (5+ years)": (5, 15),
            "Lead (8+ years)": (8, 20)
        }
        
        min_exp, max_exp = experience_ranges.get(job_level, (0, 10))
        
        if candidate_experience < min_exp:
            # Below minimum requirement
            return max(0, (candidate_experience / min_exp) * 70)
        elif candidate_experience <= max_exp:
            # Within ideal range
            return 90 + (candidate_experience - min_exp) / (max_exp - min_exp) * 10
        else:
            # Overqualified (slight penalty to avoid bias)
            return max(80, 100 - (candidate_experience - max_exp) * 2)
    
    def calculate_location_score(self, candidate_location: str, preferred_location: str) -> float:
        """Calculate location-based score with bias-free approach"""
        
        if preferred_location == "Any" or preferred_location == "Remote":
            return 100.0
        
        if candidate_location == preferred_location:
            return 100.0
        elif candidate_location == "Remote":
            return 95.0  # Remote candidates get high score for any location
        else:
            # Use location preference weights
            return self.location_preferences.get(candidate_location, 60.0) * 100
    
    def rank_candidates(self, job_title: str, required_skills: List[str], 
                       experience_level: str, location: str = "Any", 
                       max_results: int = 10) -> List[Dict]:
        """
        Main method to rank candidates based on comprehensive scoring.
        Ensures bias-free and fair evaluation.
        """
        
        scored_candidates = []
        
        for candidate in self.candidate_database:
            # Calculate individual scores
            skills_score = self.calculate_skills_score(
                candidate['skills'], required_skills, experience_level
            )
            
            experience_score = self.calculate_experience_score(
                candidate['experience'], experience_level
            )
            
            location_score = self.calculate_location_score(
                candidate['location'], location
            )
            
            # Weighted total score (bias-free weighting)
            total_score = (
                skills_score * 0.70 +      # 70% weight on skills
                experience_score * 0.20 +   # 20% weight on experience
                location_score * 0.10       # 10% weight on location
            )
            
            # Add diversity boost (small bonus to ensure diverse candidate pool)
            diversity_boost = self._calculate_diversity_boost(candidate, scored_candidates)
            total_score += diversity_boost
            
            scored_candidate = {
                **candidate,
                'skills_score': skills_score,
                'experience_score': experience_score,
                'location_score': location_score,
                'total_score': min(total_score, 100.0),  # Cap at 100
                'job_match_percentage': min(total_score, 100.0)
            }
            
            scored_candidates.append(scored_candidate)
        
        # Sort by total score (descending) and return top candidates
        ranked_candidates = sorted(
            scored_candidates, 
            key=lambda x: x['total_score'], 
            reverse=True
        )
        
        return ranked_candidates[:max_results]
    
    def _calculate_diversity_boost(self, candidate: Dict, existing_candidates: List[Dict]) -> float:
        """
        Calculate a small diversity boost to ensure fair representation.
        This helps prevent algorithmic bias.
        """
        if not existing_candidates:
            return 0.0
        
        # Location diversity
        existing_locations = [c.get('location', '') for c in existing_candidates]
        location_count = existing_locations.count(candidate['location'])
        
        if location_count == 0:
            return 2.0  # Small boost for location diversity
        elif location_count < 2:
            return 1.0
        
        return 0.0
    
    def get_skill_analysis(self, candidates: List[Dict], required_skills: List[str]) -> Dict:
        """Provide detailed skill analysis for the candidate pool"""
        
        analysis = {
            'total_candidates': len(candidates),
            'skill_coverage': {},
            'average_scores': {},
            'experience_distribution': {},
            'location_distribution': {}
        }
        
        # Skill coverage analysis
        for skill in required_skills:
            candidates_with_skill = [
                c for c in candidates if skill in c.get('skills', [])
            ]
            analysis['skill_coverage'][skill] = {
                'count': len(candidates_with_skill),
                'percentage': (len(candidates_with_skill) / len(candidates)) * 100
            }
        
        # Average scores
        if candidates:
            analysis['average_scores'] = {
                'skills': np.mean([c.get('skills_score', 0) for c in candidates]),
                'experience': np.mean([c.get('experience_score', 0) for c in candidates]),
                'location': np.mean([c.get('location_score', 0) for c in candidates]),
                'total': np.mean([c.get('total_score', 0) for c in candidates])
            }
        
        return analysis