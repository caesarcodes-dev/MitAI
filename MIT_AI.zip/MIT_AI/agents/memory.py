import sqlite3
import json
from datetime import datetime
from typing import Dict, List, Any, Optional
import os

class MemoryAgent:
    """
    AI Agent responsible for managing persistent memory using SQLite.
    Stores job searches, candidate interactions, and system learning data.
    """
    
    def __init__(self, db_path: str = "memory1.db"):
        self.db_path = db_path
        self.init_database()
    
    def init_database(self):
        """Initialize the SQLite database with required tables"""
        
        with sqlite3.connect(self.db_path) as conn:
            cursor = conn.cursor()
            
            # Job searches table
            cursor.execute('''
                CREATE TABLE IF NOT EXISTS job_searches (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    job_title TEXT NOT NULL,
                    job_description TEXT,
                    required_skills TEXT,  -- JSON array
                    experience_level TEXT,
                    preferred_location TEXT,
                    search_timestamp DATETIME DEFAULT CURRENT_TIMESTAMP,
                    results_count INTEGER,
                    search_metadata TEXT  -- JSON object
                )
            ''')
            
            # Candidate profiles table
            cursor.execute('''
                CREATE TABLE IF NOT EXISTS candidate_profiles (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    name TEXT NOT NULL,
                    email TEXT UNIQUE,
                    skills TEXT,  -- JSON array
                    experience_years INTEGER,
                    location TEXT,
                    cv_path TEXT,
                    last_updated DATETIME DEFAULT CURRENT_TIMESTAMP,
                    profile_metadata TEXT  -- JSON object
                )
            ''')
            
            # Candidate rankings table
            cursor.execute('''
                CREATE TABLE IF NOT EXISTS candidate_rankings (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    search_id INTEGER,
                    candidate_id INTEGER,
                    skills_score REAL,
                    experience_score REAL,
                    location_score REAL,
                    total_score REAL,
                    ranking_position INTEGER,
                    ranking_timestamp DATETIME DEFAULT CURRENT_TIMESTAMP,
                    FOREIGN KEY (search_id) REFERENCES job_searches (id),
                    FOREIGN KEY (candidate_id) REFERENCES candidate_profiles (id)
                )
            ''')
            
            # Interview interactions table
            cursor.execute('''
                CREATE TABLE IF NOT EXISTS interview_interactions (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    candidate_id INTEGER,
                    search_id INTEGER,
                    questions_generated TEXT,  -- JSON array
                    hr_feedback TEXT,
                    interview_status TEXT,  -- scheduled, completed, cancelled
                    interaction_timestamp DATETIME DEFAULT CURRENT_TIMESTAMP,
                    FOREIGN KEY (candidate_id) REFERENCES candidate_profiles (id),
                    FOREIGN KEY (search_id) REFERENCES job_searches (id)
                )
            ''')
            
            # System learning table (for improving recommendations)
            cursor.execute('''
                CREATE TABLE IF NOT EXISTS system_learning (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    event_type TEXT,  -- search, ranking, feedback
                    event_data TEXT,  -- JSON object
                    success_metric REAL,
                    learning_timestamp DATETIME DEFAULT CURRENT_TIMESTAMP
                )
            ''')
            
            conn.commit()
    
    def store_job_search(self, job_data: Dict[str, Any], results: List[Dict]) -> int:
        """Store a job search with its results"""
        
        with sqlite3.connect(self.db_path) as conn:
            cursor = conn.cursor()
            
            # Insert job search
            cursor.execute('''
                INSERT INTO job_searches 
                (job_title, job_description, required_skills, experience_level, 
                 preferred_location, results_count, search_metadata)
                VALUES (?, ?, ?, ?, ?, ?, ?)
            ''', (
                job_data.get('title', ''),
                job_data.get('description', ''),
                json.dumps(job_data.get('skills', [])),
                job_data.get('experience_level', ''),
                job_data.get('location', ''),
                len(results),
                json.dumps({
                    'search_params': job_data,
                    'timestamp': datetime.now().isoformat()
                })
            ))
            
            search_id = cursor.lastrowid
            
            # Store candidate rankings for this search
            for i, candidate in enumerate(results):
                self.store_candidate_ranking(search_id, candidate, i + 1)
            
            conn.commit()
            return search_id
    
    def store_candidate_profile(self, candidate: Dict[str, Any]) -> int:
        """Store or update candidate profile"""
        
        with sqlite3.connect(self.db_path) as conn:
            cursor = conn.cursor()
            
            # Check if candidate already exists
            cursor.execute('SELECT id FROM candidate_profiles WHERE email = ?', 
                         (candidate.get('email'),))
            existing = cursor.fetchone()
            
            if existing:
                # Update existing profile
                cursor.execute('''
                    UPDATE candidate_profiles 
                    SET name = ?, skills = ?, experience_years = ?, location = ?,
                        cv_path = ?, last_updated = CURRENT_TIMESTAMP,
                        profile_metadata = ?
                    WHERE email = ?
                ''', (
                    candidate.get('name', ''),
                    json.dumps(candidate.get('skills', [])),
                    candidate.get('experience', 0),
                    candidate.get('location', ''),
                    candidate.get('cv_path', ''),
                    json.dumps({
                        'last_search_score': candidate.get('total_score', 0),
                        'updated_at': datetime.now().isoformat()
                    }),
                    candidate.get('email')
                ))
                return existing[0]
            else:
                # Insert new profile
                cursor.execute('''
                    INSERT INTO candidate_profiles
                    (name, email, skills, experience_years, location, cv_path, profile_metadata)
                    VALUES (?, ?, ?, ?, ?, ?, ?)
                ''', (
                    candidate.get('name', ''),
                    candidate.get('email', ''),
                    json.dumps(candidate.get('skills', [])),
                    candidate.get('experience', 0),
                    candidate.get('location', ''),
                    candidate.get('cv_path', ''),
                    json.dumps({
                        'initial_score': candidate.get('total_score', 0),
                        'created_at': datetime.now().isoformat()
                    })
                ))
                
                conn.commit()
                return cursor.lastrowid
    
    def store_candidate_ranking(self, search_id: int, candidate: Dict[str, Any], 
                              position: int) -> int:
        """Store candidate ranking for a specific search"""
        
        # First ensure candidate profile exists
        candidate_id = self.store_candidate_profile(candidate)
        
        with sqlite3.connect(self.db_path) as conn:
            cursor = conn.cursor()
            
            cursor.execute('''
                INSERT INTO candidate_rankings
                (search_id, candidate_id, skills_score, experience_score, 
                 location_score, total_score, ranking_position)
                VALUES (?, ?, ?, ?, ?, ?, ?)
            ''', (
                search_id,
                candidate_id,
                candidate.get('skills_score', 0),
                candidate.get('experience_score', 0),
                candidate.get('location_score', 0),
                candidate.get('total_score', 0),
                position
            ))
            
            conn.commit()
            return cursor.lastrowid
    
    def store_interview_interaction(self, candidate_id: int, search_id: int,
                                  questions: List[str], status: str = 'generated') -> int:
        """Store interview questions and interactions"""
        
        with sqlite3.connect(self.db_path) as conn:
            cursor = conn.cursor()
            
            cursor.execute('''
                INSERT INTO interview_interactions
                (candidate_id, search_id, questions_generated, interview_status)
                VALUES (?, ?, ?, ?)
            ''', (
                candidate_id,
                search_id,
                json.dumps(questions),
                status
            ))
            
            conn.commit()
            return cursor.lastrowid
    
    def get_search_history(self, limit: int = 10) -> List[Dict[str, Any]]:
        """Retrieve recent search history"""
        
        with sqlite3.connect(self.db_path) as conn:
            cursor = conn.cursor()
            
            cursor.execute('''
                SELECT * FROM job_searches 
                ORDER BY search_timestamp DESC 
                LIMIT ?
            ''', (limit,))
            
            searches = []
            for row in cursor.fetchall():
                search = {
                    'id': row[0],
                    'job_title': row[1],
                    'job_description': row[2],
                    'required_skills': json.loads(row[3]) if row[3] else [],
                    'experience_level': row[4],
                    'preferred_location': row[5],
                    'search_timestamp': row[6],
                    'results_count': row[7],
                    'metadata': json.loads(row[8]) if row[8] else {}
                }
                searches.append(search)
            
            return searches
    
    def get_candidate_history(self, candidate_id: int) -> Dict[str, Any]:
        """Get complete history for a specific candidate"""
        
        with sqlite3.connect(self.db_path) as conn:
            cursor = conn.cursor()
            
            # Get candidate profile
            cursor.execute('SELECT * FROM candidate_profiles WHERE id = ?', (candidate_id,))
            profile_row = cursor.fetchone()
            
            if not profile_row:
                return {}
            
            # Get ranking history
            cursor.execute('''
                SELECT cr.*, js.job_title, js.search_timestamp
                FROM candidate_rankings cr
                JOIN job_searches js ON cr.search_id = js.id
                WHERE cr.candidate_id = ?
                ORDER BY cr.ranking_timestamp DESC
            ''', (candidate_id,))
            
            rankings = []
            for row in cursor.fetchall():
                ranking = {
                    'search_id': row[1],
                    'skills_score': row[3],
                    'experience_score': row[4],
                    'location_score': row[5],
                    'total_score': row[6],
                    'position': row[7],
                    'timestamp': row[8],
                    'job_title': row[9],
                    'search_timestamp': row[10]
                }
                rankings.append(ranking)
            
            # Get interview interactions
            cursor.execute('''
                SELECT * FROM interview_interactions 
                WHERE candidate_id = ?
                ORDER BY interaction_timestamp DESC
            ''', (candidate_id,))
            
            interviews = []
            for row in cursor.fetchall():
                interview = {
                    'search_id': row[2],
                    'questions': json.loads(row[3]) if row[3] else [],
                    'hr_feedback': row[4],
                    'status': row[5],
                    'timestamp': row[6]
                }
                interviews.append(interview)
            
            return {
                'profile': {
                    'id': profile_row[0],
                    'name': profile_row[1],
                    'email': profile_row[2],
                    'skills': json.loads(profile_row[3]) if profile_row[3] else [],
                    'experience_years': profile_row[4],
                    'location': profile_row[5],
                    'cv_path': profile_row[6],
                    'last_updated': profile_row[7],
                    'metadata': json.loads(profile_row[8]) if profile_row[8] else {}
                },
                'rankings': rankings,
                'interviews': interviews
            }
    
    def get_analytics_data(self, days: int = 30) -> Dict[str, Any]:
        """Get analytics data for the dashboard"""
        
        with sqlite3.connect(self.db_path) as conn:
            cursor = conn.cursor()
            
            # Search trends
            cursor.execute('''
                SELECT DATE(search_timestamp) as search_date, COUNT(*) as search_count
                FROM job_searches 
                WHERE search_timestamp >= date('now', '-{} days')
                GROUP BY DATE(search_timestamp)
                ORDER BY search_date
            '''.format(days))
            
            search_trends = [{'date': row[0], 'count': row[1]} for row in cursor.fetchall()]
            
            # Popular skills
            cursor.execute('''
                SELECT required_skills FROM job_searches 
                WHERE search_timestamp >= date('now', '-{} days')
            '''.format(days))
            
            all_skills = []
            for row in cursor.fetchall():
                if row[0]:
                    skills = json.loads(row[0])
                    all_skills.extend(skills)
            
            from collections import Counter
            skill_counts = Counter(all_skills).most_common(10)
            popular_skills = [{'skill': skill, 'count': count} for skill, count in skill_counts]
            
            # Average scores by experience level
            cursor.execute('''
                SELECT js.experience_level, AVG(cr.total_score) as avg_score
                FROM candidate_rankings cr
                JOIN job_searches js ON cr.search_id = js.id
                WHERE js.search_timestamp >= date('now', '-{} days')
                GROUP BY js.experience_level
            '''.format(days))
            
            score_by_level = [{'level': row[0], 'avg_score': row[1]} for row in cursor.fetchall()]
            
            return {
                'search_trends': search_trends,
                'popular_skills': popular_skills,
                'score_by_level': score_by_level,
                'total_searches': len(search_trends),
                'total_candidates': self.get_total_candidates()
            }
    
    def get_total_candidates(self) -> int:
        """Get total number of candidates in the system"""
        
        with sqlite3.connect(self.db_path) as conn:
            cursor = conn.cursor()
            cursor.execute('SELECT COUNT(*) FROM candidate_profiles')
            return cursor.fetchone()[0]
    
    def store_learning_event(self, event_type: str, event_data: Dict[str, Any], 
                           success_metric: float = 0.0):
        """Store learning events for system improvement"""
        
        with sqlite3.connect(self.db_path) as conn:
            cursor = conn.cursor()
            
            cursor.execute('''
                INSERT INTO system_learning (event_type, event_data, success_metric)
                VALUES (?, ?, ?)
            ''', (
                event_type,
                json.dumps(event_data),
                success_metric
            ))
            
            conn.commit()
    
    def get_learning_insights(self) -> Dict[str, Any]:
        """Get insights from stored learning events"""
        
        with sqlite3.connect(self.db_path) as conn:
            cursor = conn.cursor()
            
            # Get average success metrics by event type
            cursor.execute('''
                SELECT event_type, AVG(success_metric) as avg_success, COUNT(*) as event_count
                FROM system_learning 
                GROUP BY event_type
            ''')
            
            insights = {}
            for row in cursor.fetchall():
                insights[row[0]] = {
                    'avg_success': row[1],
                    'event_count': row[2]
                }
            
            return insights
    
    def cleanup_old_data(self, days_to_keep: int = 90):
        """Clean up old data to maintain performance"""
        
        with sqlite3.connect(self.db_path) as conn:
            cursor = conn.cursor()
            
            # Clean old job searches (but keep candidate profiles)
            cursor.execute('''
                DELETE FROM job_searches 
                WHERE search_timestamp < date('now', '-{} days')
            '''.format(days_to_keep))
            
            # Clean old learning events
            cursor.execute('''
                DELETE FROM system_learning 
                WHERE learning_timestamp < date('now', '-{} days')
            '''.format(days_to_keep))
            
            conn.commit()
            
            return cursor.rowcount