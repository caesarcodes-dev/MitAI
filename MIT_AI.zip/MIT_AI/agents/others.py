# agents/__init__.py
"""
AI-Powered HR Recruitment System - Multi-Agent Architecture

This package contains specialized AI agents for different aspects of the recruitment process:
- PlannerAgent: Job planning and requirement analysis
- RankingAgent: Candidate ranking and scoring
- MemoryAgent: Persistent storage and learning
- SearchAgent: Advanced candidate search capabilities
- RewriterAgent: Job description optimization
- QualityAgent: Quality assurance for matches
- ResponseAgent: Interview question generation
"""

from .planner import PlannerAgent
from .ranking import RankingAgent
from .memory import MemoryAgent

__version__ = "1.0.0"
__all__ = ["PlannerAgent", "RankingAgent", "MemoryAgent"]

# agents/search.py
from typing import List, Dict, Any, Optional
import re
from datetime import datetime

class SearchAgent:
    """
    AI Agent responsible for advanced candidate search and filtering.
    Implements semantic search and intelligent matching algorithms.
    """
    
    def __init__(self):
        self.search_history = []
        self.semantic_weights = {
            'exact_match': 1.0,
            'partial_match': 0.8,
            'semantic_match': 0.6,
            'related_match': 0.4
        }
    
    def semantic_skill_search(self, candidates: List[Dict], query_skills: List[str]) -> List[Dict]:
        """Perform semantic search for skills beyond exact matches"""
        
        skill_synonyms = {
            'machine learning': ['ml', 'artificial intelligence', 'ai', 'data science'],
            'deep learning': ['neural networks', 'cnn', 'rnn', 'transformer'],
            'frontend': ['front-end', 'ui', 'user interface', 'client-side'],
            'backend': ['back-end', 'server-side', 'api', 'microservices'],
            'devops': ['deployment', 'ci/cd', 'infrastructure', 'automation']
        }
        
        enhanced_candidates = []
        
        for candidate in candidates:
            semantic_score = 0
            candidate_skills = [s.lower() for s in candidate.get('skills', [])]
            
            for query_skill in query_skills:
                query_skill_lower = query_skill.lower()
                
                # Exact match
                if query_skill_lower in candidate_skills:
                    semantic_score += self.semantic_weights['exact_match']
                else:
                    # Check synonyms and related terms
                    for skill, synonyms in skill_synonyms.items():
                        if query_skill_lower in synonyms or skill == query_skill_lower:
                            if any(syn in ' '.join(candidate_skills) for syn in synonyms):
                                semantic_score += self.semantic_weights['semantic_match']
                            break
            
            if semantic_score > 0:
                candidate_copy = candidate.copy()
                candidate_copy['semantic_match_score'] = semantic_score
                enhanced_candidates.append(candidate_copy)
        
        return sorted(enhanced_candidates, key=lambda x: x['semantic_match_score'], reverse=True)
    
    def advanced_filter(self, candidates: List[Dict], filters: Dict[str, Any]) -> List[Dict]:
        """Apply advanced filtering with multiple criteria"""
        
        filtered = candidates.copy()
        
        # Experience range filter
        if 'min_experience' in filters:
            min_exp = filters['min_experience']
            filtered = [c for c in filtered if c.get('experience', 0) >= min_exp]
        
        if 'max_experience' in filters:
            max_exp = filters['max_experience']
            filtered = [c for c in filtered if c.get('experience', 0) <= max_exp]
        
        # Location filter with distance consideration
        if 'preferred_locations' in filters:
            locations = filters['preferred_locations']
            if 'Remote' in locations:
                # Include all remote candidates
                filtered = [c for c in filtered if 
                          c.get('location', '').lower() in [l.lower() for l in locations] or 
                          'remote' in c.get('location', '').lower()]
            else:
                filtered = [c for c in filtered if 
                          c.get('location', '').lower() in [l.lower() for l in locations]]
        
        # Skill count filter
        if 'min_skills' in filters:
            min_skills = filters['min_skills']
            filtered = [c for c in filtered if len(c.get('skills', [])) >= min_skills]
        
        # Score threshold filter
        if 'min_score' in filters:
            min_score = filters['min_score']
            filtered = [c for c in filtered if c.get('total_score', 0) >= min_score]
        
        return filtered

# agents/rewriter.py
from typing import Dict, Any, List
import re

class RewriterAgent:
    """
    AI Agent responsible for optimizing job descriptions and requirements.
    Improves job postings for better candidate attraction and matching.
    """
    
    def __init__(self):
        self.optimization_templates = {
            'ai_ml': self._get_ai_ml_template(),
            'web_dev': self._get_web_dev_template(),
            'data_science': self._get_data_science_template(),
            'devops': self._get_devops_template()
        }
    
    def optimize_job_description(self, original_description: str, job_category: str) -> Dict[str, Any]:
        """Optimize job description for better candidate matching"""
        
        optimization = {
            'original': original_description,
            'optimized': self._enhance_description(original_description, job_category),
            'improvements': [],
            'removed_bias': [],
            'added_keywords': []
        }
        
        return optimization
    
    def _enhance_description(self, description: str, category: str) -> str:
        """Enhance description with better structure and keywords"""
        
        template = self.optimization_templates.get(category, {})
        
        if not template:
            return description
        
        enhanced = f"""
{description}

{template.get('additional_context', '')}

Key Technologies: {', '.join(template.get('key_skills', []))}

What You'll Do:
{template.get('responsibilities', '')}

What We're Looking For:
{template.get('qualifications', '')}
        """.strip()
        
        return enhanced
    
    def _get_ai_ml_template(self) -> Dict[str, Any]:
        return {
            'key_skills': ['Python', 'TensorFlow', 'PyTorch', 'Machine Learning'],
            'responsibilities': """
• Design and implement machine learning models
• Collaborate with cross-functional teams
• Optimize model performance and scalability
• Stay current with AI/ML research and trends
            """.strip(),
            'qualifications': """
• Strong programming skills in Python
• Experience with ML frameworks (TensorFlow, PyTorch)
• Understanding of statistical concepts
• Problem-solving mindset
            """.strip()
        }
    
    def _get_web_dev_template(self) -> Dict[str, Any]:
        return {
            'key_skills': ['JavaScript', 'React', 'Node.js', 'HTML', 'CSS'],
            'responsibilities': """
• Develop responsive web applications
• Write clean, maintainable code
• Collaborate with designers and product managers
• Optimize applications for performance
            """.strip(),
            'qualifications': """
• Proficiency in JavaScript and modern frameworks
• Experience with version control (Git)
• Understanding of web standards and best practices
• Strong attention to detail
            """.strip()
        }
    
    def _get_data_science_template(self) -> Dict[str, Any]:
        return {
            'key_skills': ['Python', 'R', 'SQL', 'Pandas', 'Scikit-learn'],
            'responsibilities': """
• Analyze complex datasets to derive insights
• Build predictive models and algorithms
• Create data visualizations and reports
• Collaborate with stakeholders to define requirements
            """.strip(),
            'qualifications': """
• Strong analytical and statistical skills
• Experience with data manipulation and analysis
• Knowledge of machine learning techniques
• Excellent communication skills
            """.strip()
        }
    
    def _get_devops_template(self) -> Dict[str, Any]:
        return {
            'key_skills': ['Docker', 'Kubernetes', 'AWS', 'CI/CD', 'Terraform'],
            'responsibilities': """
• Design and maintain CI/CD pipelines
• Manage cloud infrastructure and deployments
• Ensure system reliability and security
• Automate operational processes
            """.strip(),
            'qualifications': """
• Experience with containerization and orchestration
• Knowledge of cloud platforms (AWS, Azure, GCP)
• Understanding of infrastructure as code
• Strong troubleshooting skills
            """.strip()
        }

# agents/quality.py
from typing import List, Dict, Any, Tuple
from datetime import datetime

class QualityAgent:
    """
    AI Agent responsible for quality assurance of candidate matches.
    Validates rankings, detects bias, and ensures match quality.
    """
    
    def __init__(self):
        self.quality_thresholds = {
            'min_match_score': 40.0,
            'max_score_variance': 20.0,
            'min_skill_overlap': 2,
            'max_bias_score': 0.3
        }
    
    def validate_rankings(self, candidates: List[Dict[str, Any]], 
                         job_requirements: Dict[str, Any]) -> Dict[str, Any]:
        """Validate candidate rankings for quality and fairness"""
        
        validation = {
            'is_valid': True,
            'quality_score': 0.0,
            'issues': [],
            'recommendations': [],
            'bias_analysis': {},
            'score_distribution': {}
        }
        
        if not candidates:
            validation['is_valid'] = False
            validation['issues'].append("No candidates to validate")
            return validation
        
        # Check score distribution
        scores = [c.get('total_score', 0) for c in candidates]
        validation['score_distribution'] = {
            'mean': sum(scores) / len(scores),
            'max': max(scores),
            'min': min(scores),
            'variance': self._calculate_variance(scores)
        }
        
        # Quality checks
        quality_issues = self._check_quality_issues(candidates, job_requirements)
        validation['issues'].extend(quality_issues)
        
        # Bias detection
        bias_analysis = self._detect_bias(candidates)
        validation['bias_analysis'] = bias_analysis
        
        if bias_analysis['bias_score'] > self.quality_thresholds['max_bias_score']:
            validation['issues'].append("Potential bias detected in rankings")
        
        # Overall quality score
        validation['quality_score'] = self._calculate_quality_score(candidates, validation)
        
        if validation['quality_score'] < 70:
            validation['is_valid'] = False
        
        return validation
    
    def _check_quality_issues(self, candidates: List[Dict], requirements: Dict) -> List[str]:
        """Check for various quality issues in candidate rankings"""
        
        issues = []
        required_skills = requirements.get('skills', [])
        
        # Check minimum skill overlap
        for candidate in candidates[:5]:  # Top 5 candidates
            candidate_skills = set(s.lower() for s in candidate.get('skills', []))
            required_skills_lower = set(s.lower() for s in required_skills)
            overlap = len(candidate_skills & required_skills_lower)
            
            if overlap < self.quality_thresholds['min_skill_overlap']:
                issues.append(f"Low skill overlap for top candidate: {candidate.get('name', 'Unknown')}")
        
        # Check score variance
        scores = [c.get('total_score', 0) for c in candidates]
        if len(set(scores)) == 1:
            issues.append("All candidates have identical scores - ranking may be ineffective")
        
        return issues
    
    def _detect_bias(self, candidates: List[Dict]) -> Dict[str, Any]:
        """Detect potential bias in candidate rankings"""
        
        bias_analysis = {
            'bias_score': 0.0,
            'location_bias': 0.0,
            'experience_bias': 0.0,
            'diversity_metrics': {}
        }
        
        if not candidates:
            return bias_analysis
        
        # Location bias detection
        locations = [c.get('location', 'Unknown') for c in candidates[:10]]
        location_diversity = len(set(locations)) / len(locations)
        bias_analysis['location_bias'] = 1.0 - location_diversity
        
        # Experience bias detection (check if all top candidates have similar experience)
        experiences = [c.get('experience', 0) for c in candidates[:5]]
        exp_variance = self._calculate_variance(experiences)
        if exp_variance < 2:  # Low variance suggests potential bias
            bias_analysis['experience_bias'] = 0.5
        
        # Overall bias score
        bias_analysis['bias_score'] = (bias_analysis['location_bias'] + 
                                     bias_analysis['experience_bias']) / 2
        
        return bias_analysis
    
    def _calculate_variance(self, values: List[float]) -> float:
        """Calculate variance of a list of values"""
        if not values:
            return 0.0
        
        mean = sum(values) / len(values)
        variance = sum((x - mean) ** 2 for x in values) / len(values)
        return variance
    
    def _calculate_quality_score(self, candidates: List[Dict], validation: Dict) -> float:
        """Calculate overall quality score for the ranking"""
        
        base_score = 100.0
        
        # Deduct points for issues
        issue_count = len(validation.get('issues', []))
        base_score -= issue_count * 10
        
        # Deduct points for high bias
        bias_score = validation.get('bias_analysis', {}).get('bias_score', 0)
        base_score -= bias_score * 50
        
        # Bonus for good score distribution
        score_dist = validation.get('score_distribution', {})
        if score_dist.get('variance', 0) > 100:  # Good variance
            base_score += 10
        return max(0, min(base_score, 100))  # Cap score between 0 and 100