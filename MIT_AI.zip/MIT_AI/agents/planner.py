from typing import Dict, List, Any
import re
from datetime import datetime

class PlannerAgent:
    """
    AI Agent responsible for job planning, requirement analysis, and search strategy.
    """
    
    def __init__(self):
        self.job_categories = {
            'AI/ML Engineer': {
                'core_skills': ['Python', 'TensorFlow', 'PyTorch', 'Scikit-learn', 'Pandas'],
                'advanced_skills': ['Transformers', 'LangChain', 'MLflow', 'Kubeflow'],
                'experience_weight': 0.25,
                'complexity_level': 'high'
            },
            'Data Scientist': {
                'core_skills': ['Python', 'R', 'SQL', 'Pandas', 'NumPy', 'Matplotlib'],
                'advanced_skills': ['Scikit-learn', 'TensorFlow', 'Tableau', 'Spark'],
                'experience_weight': 0.20,
                'complexity_level': 'medium'
            },
            'Software Engineer': {
                'core_skills': ['Python', 'JavaScript', 'Java', 'SQL', 'Git'],
                'advanced_skills': ['React', 'Node.js', 'Docker', 'Kubernetes', 'AWS'],
                'experience_weight': 0.30,
                'complexity_level': 'medium'
            },
            'DevOps Engineer': {
                'core_skills': ['Docker', 'Kubernetes', 'AWS', 'Linux', 'Git'],
                'advanced_skills': ['Terraform', 'Jenkins', 'Ansible', 'Prometheus'],
                'experience_weight': 0.35,
                'complexity_level': 'high'
            },
            'Full Stack Developer': {
                'core_skills': ['JavaScript', 'HTML', 'CSS', 'React', 'Node.js'],
                'advanced_skills': ['TypeScript', 'MongoDB', 'PostgreSQL', 'Docker'],
                'experience_weight': 0.25,
                'complexity_level': 'medium'
            }
        }
        
        self.skill_categories = {
            'programming_languages': ['Python', 'Java', 'JavaScript', 'C++', 'R', 'Scala', 'Go'],
            'ml_frameworks': ['TensorFlow', 'PyTorch', 'Keras', 'Scikit-learn', 'XGBoost'],
            'web_frameworks': ['React', 'Angular', 'Vue', 'Django', 'Flask', 'Express'],
            'databases': ['SQL', 'MongoDB', 'PostgreSQL', 'MySQL', 'Redis'],
            'cloud_platforms': ['AWS', 'Azure', 'GCP', 'Docker', 'Kubernetes'],
            'data_tools': ['Pandas', 'NumPy', 'Matplotlib', 'Seaborn', 'Tableau']
        }
    
    def analyze_job_requirements(self, job_title: str, job_description: str) -> Dict[str, Any]:
        """
        Analyze job requirements and extract key information for candidate matching.
        """
        analysis = {
            'job_category': self._classify_job_category(job_title, job_description),
            'extracted_skills': self._extract_skills_from_description(job_description),
            'experience_level': self._determine_experience_level(job_description),
            'urgency_level': self._assess_urgency(job_description),
            'remote_friendly': self._check_remote_compatibility(job_description),
            'recommended_search_strategy': {}
        }
        
        # Generate search strategy based on analysis
        analysis['recommended_search_strategy'] = self._generate_search_strategy(analysis)
        
        return analysis
    
    def _classify_job_category(self, job_title: str, job_description: str) -> str:
        """Classify the job into predefined categories"""
        
        title_lower = job_title.lower()
        desc_lower = job_description.lower()
        combined_text = f"{title_lower} {desc_lower}"
        
        # Score each category based on keyword matching
        category_scores = {}
        
        for category, details in self.job_categories.items():
            score = 0
            all_skills = details['core_skills'] + details['advanced_skills']
            
            for skill in all_skills:
                if skill.lower() in combined_text:
                    score += 1
            
            # Additional scoring based on job title keywords
            category_keywords = {
                'AI/ML Engineer': ['ai', 'ml', 'machine learning', 'artificial intelligence', 'deep learning'],
                'Data Scientist': ['data scientist', 'analytics', 'statistics', 'research'],
                'Software Engineer': ['software engineer', 'developer', 'programming'],
                'DevOps Engineer': ['devops', 'infrastructure', 'deployment', 'operations'],
                'Full Stack Developer': ['full stack', 'frontend', 'backend', 'web developer']
            }
            
            for keyword in category_keywords.get(category, []):
                if keyword in combined_text:
                    score += 2
            
            category_scores[category] = score
        
        # Return the category with the highest score
        best_category = max(category_scores.items(), key=lambda x: x[1])
        return best_category[0] if best_category[1] > 0 else 'Software Engineer'  # Default
    
    def _extract_skills_from_description(self, job_description: str) -> List[str]:
        """Extract technical skills mentioned in the job description"""
        
        desc_lower = job_description.lower()
        found_skills = []
        
        # Check all skill categories
        for category, skills in self.skill_categories.items():
            for skill in skills:
                # Use various patterns to match skills
                patterns = [
                    rf'\b{re.escape(skill.lower())}\b',
                    rf'\b{re.escape(skill.lower())}\.js\b',  # For JavaScript frameworks
                    rf'\b{re.escape(skill.lower())}\s*(framework|library)\b'
                ]
                
                for pattern in patterns:
                    if re.search(pattern, desc_lower):
                        if skill not in found_skills:
                            found_skills.append(skill)
                        break
        
        return found_skills
    
    def _determine_experience_level(self, job_description: str) -> str:
        """Determine the experience level required for the job"""
        
        desc_lower = job_description.lower()
        
        # Senior level indicators
        senior_indicators = [
            'senior', 'lead', 'principal', 'staff', 'architect',
            '5+ years', '6+ years', '7+ years', '8+ years',
            'leadership', 'mentor', 'team lead'
        ]
        
        # Junior level indicators
        junior_indicators = [
            'junior', 'entry', 'graduate', 'new grad',
            '0-2 years', '1-2 years', 'internship'
        ]
        
        # Count indicators
        senior_count = sum(1 for indicator in senior_indicators if indicator in desc_lower)
        junior_count = sum(1 for indicator in junior_indicators if indicator in desc_lower)
        
        if senior_count >= 2:
            return "Senior (5+ years)"
        elif junior_count >= 1:
            return "Junior (0-2 years)"
        else:
            return "Mid (2-5 years)"
    
    def _assess_urgency(self, job_description: str) -> str:
        """Assess the urgency level of the hiring"""
        
        desc_lower = job_description.lower()
        
        urgent_indicators = [
            'urgent', 'asap', 'immediately', 'start date',
            'fast-paced', 'growing team', 'scaling'
        ]
        
        urgency_score = sum(1 for indicator in urgent_indicators if indicator in desc_lower)
        
        if urgency_score >= 2:
            return "High"
        elif urgency_score == 1:
            return "Medium"
        else:
            return "Normal"
    
    def _check_remote_compatibility(self, job_description: str) -> bool:
        """Check if the job is remote-friendly"""
        
        desc_lower = job_description.lower()
        
        remote_indicators = [
            'remote', 'work from home', 'distributed team',
            'anywhere', 'flexible location', 'virtual'
        ]
        
        return any(indicator in desc_lower for indicator in remote_indicators)
    
    def _generate_search_strategy(self, analysis: Dict[str, Any]) -> Dict[str, Any]:
        """Generate optimized search strategy based on job analysis"""
        
        job_category = analysis['job_category']
        category_info = self.job_categories.get(job_category, self.job_categories['Software Engineer'])
        
        strategy = {
            'primary_skills': category_info['core_skills'],
            'secondary_skills': category_info['advanced_skills'],
            'skill_weight': 0.70,
            'experience_weight': category_info['experience_weight'],
            'location_weight': 0.05 if analysis['remote_friendly'] else 0.15,
            'recommended_candidates_count': self._get_recommended_count(analysis['urgency_level']),
            'search_filters': {
                'min_skill_match': 60 if analysis['urgency_level'] == 'High' else 70,
                'location_flexibility': analysis['remote_friendly'],
                'experience_range_flexibility': analysis['urgency_level'] == 'High'
            }
        }
        
        return strategy
    
    def _get_recommended_count(self, urgency: str) -> int:
        """Get recommended number of candidates based on urgency"""
        
        urgency_mapping = {
            'High': 10,
            'Medium': 7,
            'Normal': 5
        }
        
        return urgency_mapping.get(urgency, 5)
    
    def suggest_job_improvements(self, job_title: str, job_description: str) -> Dict[str, List[str]]:
        """Suggest improvements to job posting for better candidate attraction"""
        
        analysis = self.analyze_job_requirements(job_title, job_description)
        suggestions = {
            'missing_skills': [],
            'description_improvements': [],
            'title_suggestions': []
        }
        
        # Check for missing core skills
        job_category = analysis['job_category']
        category_info = self.job_categories.get(job_category)
        
        if category_info:
            extracted_skills = set(analysis['extracted_skills'])
            core_skills = set(category_info['core_skills'])
            missing_core = core_skills - extracted_skills
            
            suggestions['missing_skills'] = list(missing_core)
        
        # Description improvements
        desc_lower = job_description.lower()
        
        if len(job_description.split()) < 50:
            suggestions['description_improvements'].append(
                "Consider adding more details about the role and responsibilities"
            )
        
        if 'benefit' not in desc_lower and 'perk' not in desc_lower:
            suggestions['description_improvements'].append(
                "Consider mentioning benefits and perks to attract candidates"
            )
        
        if 'team' not in desc_lower and 'culture' not in desc_lower:
            suggestions['description_improvements'].append(
                "Consider describing the team culture and work environment"
            )
        
        # Title suggestions
        if analysis['experience_level'] not in job_title:
            level_prefix = analysis['experience_level'].split(' ')[0]
            suggestions['title_suggestions'].append(
                f"Consider adding experience level: '{level_prefix} {job_title}'"
            )
        
        return suggestions
    
    def create_job_posting_template(self, job_category: str) -> str:
        """Create a job posting template for a given category"""
        
        category_info = self.job_categories.get(job_category)
        if not category_info:
            return "Category not found"
        
        template = f"""
# {job_category} Position

## About the Role
We are looking for a talented {job_category} to join our growing team...

## Key Responsibilities
- Develop and maintain high-quality software solutions
- Collaborate with cross-functional teams
- Participate in code reviews and technical discussions
- Stay updated with the latest industry trends

## Required Skills
{', '.join(category_info['core_skills'][:5])}

## Preferred Skills
{', '.join(category_info['advanced_skills'][:5])}

## Experience Level
- {self._get_experience_description(category_info)}

## What We Offer
- Competitive salary and benefits
- Flexible working arrangements
- Professional development opportunities
- Collaborative team environment

## How to Apply
Please send your CV and cover letter...
        """
        
        return template.strip()
    
    def _get_experience_description(self, category_info: Dict) -> str:
        """Get experience description based on category complexity"""
        
        complexity = category_info.get('complexity_level', 'medium')
        
        descriptions = {
            'high': "3+ years of relevant experience with demonstrated expertise in complex projects",
            'medium': "2+ years of relevant experience with solid understanding of core concepts",
            'low': "1+ years of relevant experience or strong educational background"
        }
        
        return descriptions.get(complexity, descriptions['medium'])