import os
import re
from typing import List, Dict, Any, Optional
import json
from datetime import datetime

class CVProcessor:
    """
    Utility class for processing CVs and extracting candidate information.
    Handles PDF parsing, text extraction, and skill identification.
    """
    
    def __init__(self, docs_folder: str = "docs"):
        self.docs_folder = docs_folder
        self.skill_patterns = self._initialize_skill_patterns()
        self.experience_patterns = self._initialize_experience_patterns()
        
        # Ensure docs folder exists
        os.makedirs(self.docs_folder, exist_ok=True)
    
    def _initialize_skill_patterns(self) -> Dict[str, List[str]]:
        """Initialize regex patterns for skill extraction"""
        
        return {
            'programming_languages': [
                r'\bpython\b', r'\bjava\b', r'\bjavascript\b', r'\bc\+\+\b',
                r'\bc#\b', r'\bruby\b', r'\bgo\b', r'\brust\b', r'\bscala\b',
                r'\bkotlin\b', r'\bswift\b', r'\btypescript\b', r'\bphp\b',
                r'\br\b', r'\bmatlab\b', r'\bjulia\b'
            ],
            'ml_frameworks': [
                r'\btensorflow\b', r'\bpytorch\b', r'\bkeras\b', r'\bscikit-learn\b',
                r'\bxgboost\b', r'\blightgbm\b', r'\bcatboost\b', r'\btransformers\b',
                r'\blangchain\b', r'\bhugging\s*face\b', r'\bmlflow\b', r'\bkubeflow\b'
            ],
            'web_frameworks': [
                r'\breact\b', r'\bangular\b', r'\bvue\.?js\b', r'\bdjango\b',
                r'\bflask\b', r'\bfastapi\b', r'\bexpress\.?js\b', r'\bnode\.?js\b',
                r'\bspring\b', r'\bbootstrap\b', r'\btailwind\b'
            ],
            'databases': [
                r'\bsql\b', r'\bmysql\b', r'\bpostgresql\b', r'\bmongodb\b',
                r'\bredis\b', r'\bcassandra\b', r'\belasticsearch\b', r'\bsqlite\b',
                r'\boracle\b', r'\bneo4j\b'
            ],
            'cloud_platforms': [
                r'\baws\b', r'\bazure\b', r'\bgcp\b', r'\bgoogle\s*cloud\b',
                r'\bdocker\b', r'\bkubernetes\b', r'\bterraform\b', r'\bansible\b',
                r'\bjenkins\b', r'\bgit\b', r'\bgithub\b', r'\bgitlab\b'
            ],
            'data_tools': [
                r'\bpandas\b', r'\bnumpy\b', r'\bmatplotlib\b', r'\bseaborn\b',
                r'\bplotly\b', r'\btableau\b', r'\bpower\s*bi\b', r'\bspark\b',
                r'\bhadoop\b', r'\bairflow\b', r'\bkafka\b'
            ],
            'ai_specific': [
                r'\bcomputer\s*vision\b', r'\bnlp\b', r'\bnatural\s*language\s*processing\b',
                r'\bdeep\s*learning\b', r'\bmachine\s*learning\b', r'\bneural\s*networks\b',
                r'\bcnn\b', r'\brnn\b', r'\blstm\b', r'\bgru\b', r'\btransformer\b',
                r'\bert\b', r'\bgpt\b', r'\bllm\b', r'\bopen\s*cv\b', r'\byolo\b'
            ]
        }
    
    def _initialize_experience_patterns(self) -> List[str]:
        """Initialize patterns for experience extraction"""
        
        return [
            r'(\d+)\+?\s*years?\s*of\s*experience',
            r'(\d+)\+?\s*years?\s*experience',
            r'experience:\s*(\d+)\+?\s*years?',
            r'(\d+)\+?\s*yrs?\s*experience',
            r'worked\s*for\s*(\d+)\+?\s*years?',
            r'(\d+)\+?\s*years?\s*in\s*\w+',
            r'over\s*(\d+)\+?\s*years?',
            r'more\s*than\s*(\d+)\+?\s*years?'
        ]
    
    def extract_text_from_pdf(self, pdf_path: str) -> str:
        """
        Extract text from PDF file. 
        In a real implementation, this would use libraries like PyPDF2, pdfplumber, etc.
        For demo purposes, we'll simulate text extraction.
        """
        
        # Simulate PDF text extraction
        # In real implementation, use: PyPDF2, pdfplumber, or pdfminer
        
        # Mock CV texts for demonstration
        mock_cv_texts = [
            """
            John Doe
            Senior AI Engineer
            Email: john.doe@email.com
            Phone: +1-555-0123
            Location: San Francisco, CA
            
            EXPERIENCE
            5+ years of experience in machine learning and artificial intelligence
            
            SKILLS
            - Programming Languages: Python, Java, C++
            - ML Frameworks: TensorFlow, PyTorch, Scikit-learn
            - Cloud Platforms: AWS, Docker, Kubernetes
            - Databases: PostgreSQL, MongoDB
            - Tools: Git, MLflow, Airflow
            
            WORK EXPERIENCE
            Senior AI Engineer at TechCorp (2020-Present)
            - Developed deep learning models using PyTorch and TensorFlow
            - Implemented computer vision solutions with OpenCV
            - Deployed models on AWS using Docker and Kubernetes
            
            AI Engineer at StartupAI (2018-2020)
            - Built NLP models using transformers and BERT
            - Worked with large datasets using Pandas and NumPy
            """,
            """
            Sarah Wilson
            Full Stack Developer
            Email: sarah.wilson@email.com
            Location: Remote
            
            EXPERIENCE
            3 years of web development experience
            
            TECHNICAL SKILLS
            - Frontend: React, Vue.js, TypeScript, HTML, CSS
            - Backend: Node.js, Express, FastAPI, Django
            - Databases: MySQL, MongoDB, Redis
            - Cloud: AWS, Docker, Git
            - Testing: Jest, Cypress
            
            PROFESSIONAL EXPERIENCE
            Full Stack Developer at WebSolutions (2021-Present)
            - Built responsive web applications using React and Node.js
            - Designed REST APIs with Express and FastAPI
            - Managed databases with MySQL and MongoDB
            """,
            """
            Michael Chen
            Data Scientist
            Email: m.chen@email.com
            Location: New York, NY
            
            EXPERIENCE
            4 years in data science and analytics
            
            SKILLS
            - Programming: Python, R, SQL
            - ML Libraries: Scikit-learn, XGBoost, TensorFlow
            - Data Tools: Pandas, NumPy, Matplotlib, Seaborn
            - Visualization: Tableau, Plotly, Power BI
            - Cloud: Azure, GCP
            
            WORK HISTORY
            Senior Data Scientist at FinanceAI (2021-Present)
            - Developed predictive models using machine learning
            - Created interactive dashboards with Tableau
            - Analyzed large datasets using Python and SQL
            """
        ]
        
        # Return a random mock CV text based on file path
        import hashlib
        file_hash = int(hashlib.md5(pdf_path.encode()).hexdigest(), 16)
        return mock_cv_texts[file_hash % len(mock_cv_texts)]
    
    def extract_skills_from_text(self, text: str) -> List[str]:
        """Extract technical skills from CV text"""
        
        text_lower = text.lower()
        found_skills = []
        
        for category, patterns in self.skill_patterns.items():
            for pattern in patterns:
                matches = re.findall(pattern, text_lower, re.IGNORECASE)
                for match in matches:
                    # Clean up the match
                    skill = match.strip()
                    if skill and skill not in [s.lower() for s in found_skills]:
                        # Convert back to proper case
                        if skill == 'python':
                            found_skills.append('Python')
                        elif skill == 'javascript':
                            found_skills.append('JavaScript')
                        elif skill == 'tensorflow':
                            found_skills.append('TensorFlow')
                        elif skill == 'pytorch':
                            found_skills.append('PyTorch')
                        elif skill == 'aws':
                            found_skills.append('AWS')
                        elif skill == 'docker':
                            found_skills.append('Docker')
                        elif skill == 'kubernetes':
                            found_skills.append('Kubernetes')
                        else:
                            found_skills.append(skill.title())
        
        return found_skills
    
    def extract_experience_years(self, text: str) -> int:
        """Extract years of experience from CV text"""
        
        text_lower = text.lower()
        experience_years = []
        
        for pattern in self.experience_patterns:
            matches = re.findall(pattern, text_lower, re.IGNORECASE)
            for match in matches:
                try:
                    years = int(match)
                    if 0 <= years <= 50:  # Reasonable range
                        experience_years.append(years)
                except ValueError:
                    continue
        
        # Return the maximum experience found, or 0 if none
        return max(experience_years) if experience_years else 0
    
    def extract_contact_info(self, text: str) -> Dict[str, str]:
        """Extract contact information from CV text"""
        
        contact_info = {
            'name': '',
            'email': '',
            'phone': '',
            'location': ''
        }
        
        # Extract email
        email_pattern = r'\b[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\.[A-Z|a-z]{2,}\b'
        email_match = re.search(email_pattern, text)
        if email_match:
            contact_info['email'] = email_match.group()
        
        # Extract phone
        phone_patterns = [
            r'\+?1?[-.\s]?\(?\d{3}\)?[-.\s]?\d{3}[-.\s]?\d{4}',
            r'\+\d{1,3}[-.\s]?\d{3,4}[-.\s]?\d{3,4}[-.\s]?\d{3,4}'
        ]
        
        for pattern in phone_patterns:
            phone_match = re.search(pattern, text)
            if phone_match:
                contact_info['phone'] = phone_match.group()
                break
        
        # Extract name (first line usually contains name)
        lines = text.strip().split('\n')
        for line in lines:
            line = line.strip()
            if line and not any(keyword in line.lower() for keyword in 
                              ['email', 'phone', 'address', 'location', '@']):
                # Check if line looks like a name
                words = line.split()
                if 2 <= len(words) <= 4 and all(word.isalpha() or word.replace('.', '').isalpha() 
                                               for word in words):
                    contact_info['name'] = line
                    break
        
        # Extract location
        location_patterns = [
            r'location:\s*([^\n\r]+)',
            r'address:\s*([^\n\r]+)',
            r'based\s*in\s*([^\n\r]+)',
            r'([A-Za-z\s]+,\s*[A-Z]{2})',  # City, State
            r'([A-Za-z\s]+,\s*[A-Za-z\s]+)'  # City, Country
        ]
        
        for pattern in location_patterns:
            location_match = re.search(pattern, text, re.IGNORECASE)
            if location_match:
                location = location_match.group(1).strip()
                if len(location.split()) <= 4:  # Reasonable location length
                    contact_info['location'] = location
                    break
        
        return contact_info
    
    def process_cv(self, cv_path: str) -> Dict[str, Any]:
        """Process a single CV and extract all relevant information"""
        
        if not os.path.exists(cv_path):
            raise FileNotFoundError(f"CV file not found: {cv_path}")
        
        # Extract text from PDF
        text = self.extract_text_from_pdf(cv_path)
        
        # Extract contact information
        contact_info = self.extract_contact_info(text)
        
        # Extract skills
        skills = self.extract_skills_from_text(text)
        
        # Extract experience
        experience_years = self.extract_experience_years(text)
        
        # Compile candidate profile
        candidate_profile = {
            'name': contact_info['name'] or f"Candidate_{os.path.basename(cv_path)}",
            'email': contact_info['email'] or f"candidate_{hash(cv_path) % 10000}@email.com",
            'phone': contact_info['phone'],
            'location': contact_info['location'] or 'Unknown',
            'skills': skills,
            'experience': experience_years,
            'cv_path': cv_path,
            'processed_at': datetime.now().isoformat(),
            'raw_text_length': len(text)
        }
        
        return candidate_profile
    
    def process_all_cvs(self) -> List[Dict[str, Any]]:
        """Process all CV files in the docs folder"""
        
        candidates = []
        
        if not os.path.exists(self.docs_folder):
            print(f"Warning: Docs folder '{self.docs_folder}' not found. Creating empty folder.")
            os.makedirs(self.docs_folder)
            return candidates
        
        # Find all PDF files
        pdf_files = [f for f in os.listdir(self.docs_folder) if f.lower().endswith('.pdf')]
        
        if not pdf_files:
            print(f"No PDF files found in {self.docs_folder}")
            # Generate sample candidates for demo
            return self._generate_sample_candidates()
        
        for pdf_file in pdf_files:
            cv_path = os.path.join(self.docs_folder, pdf_file)
            
            try:
                candidate = self.process_cv(cv_path)
                candidates.append(candidate)
                print(f"Processed: {pdf_file}")
            
            except Exception as e:
                print(f"Error processing {pdf_file}: {str(e)}")
        
        return candidates
    
    def _generate_sample_candidates(self) -> List[Dict[str, Any]]:
        """Generate sample candidates when no CVs are available"""
        
        sample_candidates = [
            {
                'name': 'Alex Rodriguez',
                'email': 'alex.rodriguez@email.com',
                'phone': '+1-555-0101',
                'location': 'San Francisco, CA',
                'skills': ['Python', 'TensorFlow', 'PyTorch', 'AWS', 'Docker', 'Kubernetes'],
                'experience': 6,
                'cv_path': 'docs/sample_cv_1.pdf',
                'processed_at': datetime.now().isoformat(),
                'raw_text_length': 1500
            },
            {
                'name': 'Sarah Chen',
                'email': 'sarah.chen@email.com',
                'phone': '+1-555-0102',
                'location': 'Remote',
                'skills': ['React', 'Node.js', 'TypeScript', 'MongoDB', 'AWS'],
                'experience': 4,
                'cv_path': 'docs/sample_cv_2.pdf',
                'processed_at': datetime.now().isoformat(),
                'raw_text_length': 1200
            },
            {
                'name': 'Michael Johnson',
                'email': 'michael.j@email.com',
                'phone': '+1-555-0103',
                'location': 'New York, NY',
                'skills': ['Python', 'Scikit-learn', 'Pandas', 'SQL', 'Tableau'],
                'experience': 3,
                'cv_path': 'docs/sample_cv_3.pdf',
                'processed_at': datetime.now().isoformat(),
                'raw_text_length': 1350
            }
        ]
        
        return sample_candidates
    
    def save_processed_candidates(self, candidates: List[Dict[str, Any]], 
                                output_file: str = "processed_candidates.json"):
        """Save processed candidate data to JSON file"""
        
        output_path = os.path.join(self.docs_folder, output_file)
        
        with open(output_path, 'w', encoding='utf-8') as f:
            json.dump(candidates, f, indent=2, ensure_ascii=False)
        
        print(f"Saved {len(candidates)} candidates to {output_path}")
    
    def load_processed_candidates(self, input_file: str = "processed_candidates.json") -> List[Dict[str, Any]]:
        """Load previously processed candidate data"""
        
        input_path = os.path.join(self.docs_folder, input_file)
        
        if not os.path.exists(input_path):
            print(f"No saved candidates found at {input_path}")
            return []
        
        try:
            with open(input_path, 'r', encoding='utf-8') as f:
                candidates = json.load(f)
            
            print(f"Loaded {len(candidates)} candidates from {input_path}")
            return candidates
        
        except Exception as e:
            print(f"Error loading candidates: {str(e)}")
            return []
    
    def get_skill_statistics(self, candidates: List[Dict[str, Any]]) -> Dict[str, Any]:
        """Get statistics about skills across all candidates"""
        
        all_skills = []
        skill_frequency = {}
        
        for candidate in candidates:
            candidate_skills = candidate.get('skills', [])
            all_skills.extend(candidate_skills)
            
            for skill in candidate_skills:
                skill_frequency[skill] = skill_frequency.get(skill, 0) + 1
        
        # Sort by frequency
        sorted_skills = sorted(skill_frequency.items(), key=lambda x: x[1], reverse=True)
        
        return {
            'total_unique_skills': len(skill_frequency),
            'most_common_skills': sorted_skills[:10],
            'total_skill_mentions': len(all_skills),
            'avg_skills_per_candidate': len(all_skills) / len(candidates) if candidates else 0,
            'skill_distribution_by_category': self._categorize_skills(list(skill_frequency.keys()))
        }
    
    def _categorize_skills(self, skills: List[str]) -> Dict[str, List[str]]:
        """Categorize skills into different groups"""
        
        categorized = {
            'Programming Languages': [],
            'ML/AI Frameworks': [],
            'Web Technologies': [],
            'Databases': [],
            'Cloud & DevOps': [],
            'Data Science Tools': [],
            'Other': []
        }
        
        for skill in skills:
            skill_lower = skill.lower()
            
            if any(lang in skill_lower for lang in ['python', 'java', 'javascript', 'c++', 'typescript']):
                categorized['Programming Languages'].append(skill)
            elif any(ml in skill_lower for ml in ['tensorflow', 'pytorch', 'keras', 'scikit']):
                categorized['ML/AI Frameworks'].append(skill)
            elif any(web in skill_lower for web in ['react', 'angular', 'vue', 'django', 'flask']):
                categorized['Web Technologies'].append(skill)
            elif any(db in skill_lower for db in ['sql', 'mongodb', 'postgresql', 'mysql']):
                categorized['Databases'].append(skill)
            elif any(cloud in skill_lower for cloud in ['aws', 'azure', 'gcp', 'docker', 'kubernetes']):
                categorized['Cloud & DevOps'].append(skill)
            elif any(data in skill_lower for data in ['pandas', 'numpy', 'matplotlib', 'tableau']):
                categorized['Data Science Tools'].append(skill)
            else:
                categorized['Other'].append(skill)
        
        return categorized