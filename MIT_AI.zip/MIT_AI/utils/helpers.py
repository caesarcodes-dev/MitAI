import re
import random
from typing import List, Dict, Any
from datetime import datetime

def generate_interview_questions(job_title: str, required_skills: List[str], 
                                candidate_skills: List[str]) -> List[str]:
    """
    Generate intelligent interview questions based on job requirements and candidate skills.
    Focuses on technical depth and practical application.
    """
    
    questions = []
    
    # Question templates based on different skill categories
    question_templates = {
        'Python': [
            "Can you explain the difference between list comprehensions and generator expressions in Python? When would you use each?",
            "How would you optimize a Python script that's processing large datasets? Walk me through your approach.",
            "Describe a challenging Python debugging session you've had. How did you identify and solve the issue?"
        ],
        'PyTorch': [
            "Design a training loop for a computer vision model using PyTorch. What key components would you include?",
            "How would you implement custom loss functions in PyTorch? Can you give me an example scenario?",
            "Explain the difference between PyTorch's dynamic and static computation graphs. When is each beneficial?"
        ],
        'TensorFlow': [
            "How would you deploy a TensorFlow model to production? Walk me through the entire pipeline.",
            "Explain TensorFlow's eager execution vs. graph execution. What are the trade-offs?",
            "Design a distributed training setup using TensorFlow. What challenges might you encounter?"
        ],
        'React': [
            "How would you optimize a React application that's experiencing performance issues with large lists?",
            "Explain the concept of React hooks. Can you create a custom hook for API data fetching?",
            "Walk me through how you would implement state management in a complex React application."
        ],
        'AWS': [
            "Design a scalable architecture on AWS for a machine learning application. What services would you use?",
            "How would you implement CI/CD for ML models using AWS services?",
            "Explain AWS IAM best practices for a team of data scientists. How would you structure permissions?"
        ],
        'Docker': [
            "How would you optimize Docker images for machine learning applications? What strategies would you use?",
            "Explain how you would set up a multi-container application using Docker Compose.",
            "Walk me through troubleshooting a Docker container that's running out of memory in production."
        ],
        'SQL': [
            "Design a database schema for a recommendation system. How would you handle large-scale queries?",
            "Explain how you would optimize a slow SQL query. What steps would you take?",
            "How would you implement data versioning in a SQL database for ML experiments?"
        ],
        'Machine Learning': [
            "How would you approach a problem where your model performs well on training data but poorly on validation data?",
            "Explain your process for feature selection in a high-dimensional dataset.",
            "Walk me through how you would design an A/B test for a new ML model in production."
        ]
    }
    
    # Behavioral questions based on job level
    behavioral_questions = {
        'Junior': [
            "Tell me about a time when you had to learn a new technology quickly. How did you approach it?",
            "Describe a project where you had to work with incomplete requirements. How did you handle it?",
            "How do you stay updated with the latest developments in your field?"
        ],
        'Mid': [
            "Describe a time when you had to make a trade-off between code quality and delivery speed. How did you decide?",
            "Tell me about a technical challenge you faced that required creative problem-solving.",
            "How would you explain a complex technical concept to a non-technical stakeholder?"
        ],
        'Senior': [
            "Tell me about a time when you mentored a junior developer. What was your approach?",
            "Describe a situation where you had to make an architectural decision that affected the entire team.",
            "How do you approach technical debt in a fast-moving development environment?"
        ]
    }
    
    # Generate skill-specific questions
    for skill in required_skills[:3]:  # Top 3 required skills
        if skill in candidate_skills and skill in question_templates:
            skill_questions = question_templates[skill]
            if skill_questions:
                questions.append(random.choice(skill_questions))
    
    # Add general ML/programming questions if applicable
    ml_related = any(skill in ['TensorFlow', 'PyTorch', 'Scikit-learn', 'Machine Learning'] 
                    for skill in required_skills + candidate_skills)
    
    if ml_related and 'Machine Learning' in question_templates:
        questions.append(random.choice(question_templates['Machine Learning']))
    
    # Add behavioral question based on job level
    job_level = determine_job_level(job_title)
    if job_level in behavioral_questions:
        questions.append(random.choice(behavioral_questions[job_level]))
    
    # Ensure we have at least 2-3 questions
    if len(questions) < 2:
        # Add fallback questions
        fallback_questions = [
            "Tell me about your most challenging project and how you overcame the obstacles.",
            "How do you approach debugging complex technical issues?",
            "Describe your development workflow and the tools you use daily."
        ]
        questions.extend(fallback_questions[:3-len(questions)])
    
    return questions[:3]  # Return max 3 questions

def determine_job_level(job_title: str) -> str:
    """Determine job level from job title"""
    
    title_lower = job_title.lower()
    
    if any(level in title_lower for level in ['senior', 'lead', 'principal', 'staff']):
        return 'Senior'
    elif any(level in title_lower for level in ['junior', 'entry', 'associate']):
        return 'Junior'
    else:
        return 'Mid'

def extract_skills_from_text(text: str) -> List[str]:
    """
    Extract technical skills from job description or CV text.
    """
    
    # Common technical skills dictionary
    skills_dict = {
        # Programming Languages
        'python': 'Python',
        'java': 'Java',
        'javascript': 'JavaScript',
        'typescript': 'TypeScript',
        'c++': 'C++',
        'c#': 'C#',
        'go': 'Go',
        'rust': 'Rust',
        'scala': 'Scala',
        'r': 'R',
        
        # Web Technologies
        'react': 'React',
        'angular': 'Angular',
        'vue': 'Vue.js',
        'node.js': 'Node.js',
        'express': 'Express.js',
        'django': 'Django',
        'flask': 'Flask',
        'fastapi': 'FastAPI',
        
        # Databases
        'sql': 'SQL',
        'mysql': 'MySQL',
        'postgresql': 'PostgreSQL',
        'mongodb': 'MongoDB',
        'redis': 'Redis',
        'elasticsearch': 'Elasticsearch',
        
        # ML/AI
        'tensorflow': 'TensorFlow',
        'pytorch': 'PyTorch',
        'keras': 'Keras',
        'scikit-learn': 'Scikit-learn',
        'pandas': 'Pandas',
        'numpy': 'NumPy',
        'matplotlib': 'Matplotlib',
        'seaborn': 'Seaborn',
        'opencv': 'OpenCV',
        'transformers': 'Transformers',
        'langchain': 'LangChain',
        
        # Cloud & DevOps
        'aws': 'AWS',
        'azure': 'Azure',
        'gcp': 'GCP',
        'docker': 'Docker',
        'kubernetes': 'Kubernetes',
        'terraform': 'Terraform',
        'jenkins': 'Jenkins',
        'git': 'Git',
    }
    
    text_lower = text.lower()
    found_skills = []
    
    # Use regex to find skills with word boundaries
    for skill_key, skill_name in skills_dict.items():
        # Create pattern with word boundaries
        pattern = r'\b' + re.escape(skill_key) + r'\b'
        if re.search(pattern, text_lower):
            found_skills.append(skill_name)
    
    # Remove duplicates while preserving order
    seen = set()
    unique_skills = []
    for skill in found_skills:
        if skill not in seen:
            seen.add(skill)
            unique_skills.append(skill)
    
    return unique_skills

def calculate_skill_match_score(candidate_skills: List[str], required_skills: List[str]) -> float:
    """
    Calculate how well candidate skills match job requirements.
    Returns a score between 0 and 100.
    """
    
    if not required_skills:
        return 50.0  # Neutral score if no requirements specified
    
    if not candidate_skills:
        return 0.0
    
    # Convert to lowercase for comparison
    candidate_skills_lower = [skill.lower() for skill in candidate_skills]
    required_skills_lower = [skill.lower() for skill in required_skills]
    
    # Exact matches
    exact_matches = len(set(candidate_skills_lower) & set(required_skills_lower))
    
    # Partial matches (for related skills)
    partial_matches = 0
    skill_relationships = {
        'tensorflow': ['keras', 'pytorch'],
        'pytorch': ['tensorflow', 'keras'],
        'react': ['vue.js', 'angular'],
        'mysql': ['postgresql', 'sql'],
        'aws': ['azure', 'gcp'],
        'docker': ['kubernetes'],
        'python': ['r', 'scala'],
        'javascript': ['typescript']
    }
    
    for required_skill in required_skills_lower:
        if required_skill not in candidate_skills_lower:
            # Check for related skills
            related_skills = skill_relationships.get(required_skill, [])
            if any(related in candidate_skills_lower for related in related_skills):
                partial_matches += 0.7  # 70% credit for related skills
    
    # Calculate score
    total_matches = exact_matches + partial_matches
    max_possible_matches = len(required_skills)
    
    score = (total_matches / max_possible_matches) * 100
    return min(score, 100.0)  # Cap at 100

def format_score_display(score: float) -> Dict[str, Any]:
    """
    Format score for display with color coding and labels.
    """
    
    if score >= 80:
        return {
            'score': score,
            'label': 'Excellent Match',
            'color': '#28a745',  # Green
            'class': 'score-high'
        }
    elif score >= 60:
        return {
            'score': score,
            'label': 'Good Match',
            'color': '#ffc107',  # Yellow
            'class': 'score-medium'
        }
    elif score >= 40:
        return {
            'score': score,
            'label': 'Fair Match',
            'color': '#fd7e14',  # Orange
            'class': 'score-medium'
        }
    else:
        return {
            'score': score,
            'label': 'Poor Match',
            'color': '#dc3545',  # Red
            'class': 'score-low'
        }

def generate_candidate_summary(candidate: Dict[str, Any]) -> str:
    """
    Generate a concise summary of candidate profile.
    """
    
    name = candidate.get('name', 'Unknown')
    experience = candidate.get('experience', 0)
    location = candidate.get('location', 'Unknown')
    skills = candidate.get('skills', [])
    total_score = candidate.get('total_score', 0)
    
    # Get top skills
    top_skills = ', '.join(skills[:5]) if skills else 'No skills listed'
    
    # Experience level description
    if experience <= 2:
        exp_level = "Junior"
    elif experience <= 5:
        exp_level = "Mid-level"
    elif experience <= 8:
        exp_level = "Senior"
    else:
        exp_level = "Expert"
    
    summary = f"""
    {name} is a {exp_level} professional with {experience} years of experience, 
    based in {location}. Key skills include: {top_skills}. 
    Overall match score: {total_score:.1f}/100.
    """.strip()
    
    return summary

def validate_email(email: str) -> bool:
    """
    Validate email address format.
    """
    
    email_pattern = r'^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}$'
    return bool(re.match(email_pattern, email))

def anonymize_candidate_data(candidate: Dict[str, Any], anonymize_name: bool = True) -> Dict[str, Any]:
    """
    Anonymize candidate data to reduce bias in selection process.
    """
    
    anonymized = candidate.copy()
    
    if anonymize_name and 'name' in anonymized:
        # Replace name with anonymous identifier
        anonymized['name'] = f"Candidate_{hash(candidate.get('email', '')) % 10000}"
    
    # Remove potentially biasing information
    bias_fields = ['phone', 'photo_url', 'gender', 'age']
    for field in bias_fields:
        if field in anonymized:
            del anonymized[field]
    
    return anonymized

def calculate_diversity_score(candidates: List[Dict[str, Any]]) -> Dict[str, Any]:
    """
    Calculate diversity metrics for candidate pool.
    """
    
    if not candidates:
        return {'diversity_score': 0, 'metrics': {}}
    
    # Location diversity
    locations = [c.get('location', 'Unknown') for c in candidates]
    unique_locations = len(set(locations))
    location_diversity = unique_locations / len(candidates)
    
    # Experience diversity
    experiences = [c.get('experience', 0) for c in candidates]
    exp_ranges = {
        'junior': len([e for e in experiences if e <= 2]),
        'mid': len([e for e in experiences if 2 < e <= 5]),
        'senior': len([e for e in experiences if 5 < e <= 8]),
        'expert': len([e for e in experiences if e > 8])
    }
    
    # Calculate experience distribution evenness
    total_candidates = len(candidates)
    exp_distribution = [count/total_candidates for count in exp_ranges.values() if count > 0]
    exp_diversity = len(exp_distribution) / 4  # Max 4 categories
    
    # Overall diversity score
    diversity_score = (location_diversity + exp_diversity) / 2
    
    return {
        'diversity_score': diversity_score,
        'metrics': {
            'location_diversity': location_diversity,
            'unique_locations': unique_locations,
            'experience_diversity': exp_diversity,
            'experience_distribution': exp_ranges
        }
    }

def generate_search_recommendations(search_history: List[Dict[str, Any]]) -> List[str]:
    """
    Generate search recommendations based on history.
    """
    
    if not search_history:
        return [
            "Try searching for AI/ML engineers with PyTorch experience",
            "Consider expanding your location criteria to include remote candidates",
            "Look for full-stack developers with React and Node.js skills"
        ]
    
    recommendations = []
    
    # Analyze most searched skills
    all_skills = []
    for search in search_history[-5:]:  # Last 5 searches
        skills = search.get('required_skills', [])
        all_skills.extend(skills)
    
    if all_skills:
        from collections import Counter
        skill_counts = Counter(all_skills)
        top_skill = skill_counts.most_common(1)[0][0]
        recommendations.append(f"Consider searching for candidates with {top_skill} and complementary skills")
    
    # Location analysis
    locations = [s.get('preferred_location', '') for s in search_history[-5:]]
    if 'Remote' not in locations:
        recommendations.append("Consider including remote candidates to expand your talent pool")
    
    # Experience level suggestions
    exp_levels = [s.get('experience_level', '') for s in search_history[-5:]]
    if len(set(exp_levels)) == 1:
        recommendations.append("Try searching across different experience levels for better diversity")
    
    return recommendations[:3]

def export_candidates_to_csv(candidates: List[Dict[str, Any]], filename: str = None) -> str:
    """
    Export candidate data to CSV format.
    """
    
    import csv
    import io
    from datetime import datetime
    
    if not filename:
        filename = f"candidates_export_{datetime.now().strftime('%Y%m%d_%H%M%S')}.csv"
    
    # Prepare CSV data
    output = io.StringIO()
    
    if not candidates:
        return ""
    
    # Define CSV headers
    headers = [
        'Name', 'Email', 'Location', 'Experience (Years)',
        'Skills Count', 'Top Skills', 'Total Score',
        'Skills Score', 'Experience Score', 'Location Score'
    ]
    
    writer = csv.DictWriter(output, fieldnames=headers)
    writer.writeheader()
    
    for candidate in candidates:
        skills = candidate.get('skills', [])
        top_skills = ', '.join(skills[:5]) if skills else ''
        
        row = {
            'Name': candidate.get('name', ''),
            'Email': candidate.get('email', ''),
            'Location': candidate.get('location', ''),
            'Experience (Years)': candidate.get('experience', 0),
            'Skills Count': len(skills),
            'Top Skills': top_skills,
            'Total Score': round(candidate.get('total_score', 0), 1),
            'Skills Score': round(candidate.get('skills_score', 0), 1),
            'Experience Score': round(candidate.get('experience_score', 0), 1),
            'Location Score': round(candidate.get('location_score', 0), 1)
        }
        writer.writerow(row)
    
    return output.getvalue()

def create_interview_schedule_template(candidate: Dict[str, Any], 
                                     questions: List[str]) -> str:
    """
    Create an interview schedule template.
    """
    
    template = f"""
INTERVIEW SCHEDULE TEMPLATE

Candidate: {candidate.get('name', 'TBD')}
Email: {candidate.get('email', 'TBD')}
Position: [Job Title]
Date: [Interview Date]
Time: [Interview Time]
Duration: 60 minutes
Interviewer(s): [Interviewer Names]

CANDIDATE OVERVIEW:
- Experience: {candidate.get('experience', 0)} years
- Location: {candidate.get('location', 'Unknown')}
- Key Skills: {', '.join(candidate.get('skills', [])[:5])}
- Match Score: {candidate.get('total_score', 0):.1f}/100

SUGGESTED INTERVIEW STRUCTURE:

1. Introduction (5 minutes)
   - Welcome and introductions
   - Brief overview of the role and company

2. Technical Discussion (30 minutes)
   Questions to cover:
"""
    
    for i, question in enumerate(questions, 1):
        template += f"   {i}. {question}\n"
    
    template += """
3. Candidate Questions (15 minutes)
   - Allow candidate to ask questions about the role, team, and company

4. Next Steps (10 minutes)
   - Explain the interview process timeline
   - Provide contact information for follow-up

EVALUATION CRITERIA:
□ Technical competency
□ Problem-solving approach
□ Communication skills
□ Cultural fit
□ Enthusiasm for the role

NOTES SECTION:
[Space for interviewer notes]

POST-INTERVIEW ACTION ITEMS:
□ Complete evaluation form
□ Share feedback with hiring team
□ Schedule follow-up if appropriate
"""
    
    return template

def get_skill_learning_resources(skills: List[str]) -> Dict[str, List[Dict[str, str]]]:
    """
    Get learning resources for skills to help with interview preparation.
    """
    
    resources = {
        'Python': [
            {'type': 'Documentation', 'name': 'Official Python Docs', 'url': 'https://docs.python.org/'},
            {'type': 'Practice', 'name': 'LeetCode Python', 'url': 'https://leetcode.com/problemset/'},
            {'type': 'Book', 'name': 'Effective Python', 'url': 'https://effectivepython.com/'}
        ],
        'PyTorch': [
            {'type': 'Tutorial', 'name': 'PyTorch Tutorials', 'url': 'https://pytorch.org/tutorials/'},
            {'type': 'Course', 'name': 'Fast.ai Practical Deep Learning', 'url': 'https://course.fast.ai/'},
            {'type': 'Documentation', 'name': 'PyTorch Docs', 'url': 'https://pytorch.org/docs/'}
        ],
        'React': [
            {'type': 'Documentation', 'name': 'React Official Docs', 'url': 'https://react.dev/'},
            {'type': 'Tutorial', 'name': 'React Tutorial', 'url': 'https://react.dev/learn'},
            {'type': 'Practice', 'name': 'React Challenges', 'url': 'https://reactjs.org/community/courses.html'}
        ],
        'AWS': [
            {'type': 'Training', 'name': 'AWS Training', 'url': 'https://aws.amazon.com/training/'},
            {'type': 'Documentation', 'name': 'AWS Documentation', 'url': 'https://docs.aws.amazon.com/'},
            {'type': 'Certification', 'name': 'AWS Certification', 'url': 'https://aws.amazon.com/certification/'}
        ]
    }
    
    relevant_resources = {}
    for skill in skills:
        if skill in resources:
            relevant_resources[skill] = resources[skill]
    
    return relevant_resources

def validate_job_requirements(job_data: Dict[str, Any]) -> Dict[str, Any]:
    """
    Validate job posting requirements and suggest improvements.
    """
    
    validation_result = {
        'is_valid': True,
        'errors': [],
        'warnings': [],
        'suggestions': []
    }
    
    # Required fields validation
    required_fields = ['title', 'skills']
    for field in required_fields:
        if not job_data.get(field):
            validation_result['errors'].append(f"Missing required field: {field}")
            validation_result['is_valid'] = False
    
    # Skills validation
    skills = job_data.get('skills', [])
    if len(skills) < 2:
        validation_result['warnings'].append("Consider adding more required skills for better matching")
    
    if len(skills) > 10:
        validation_result['warnings'].append("Too many required skills might limit candidate pool")
    
    # Job title validation
    title = job_data.get('title', '')
    if len(title) < 10:
        validation_result['warnings'].append("Job title might be too short - consider adding more context")
    
    # Description validation
    description = job_data.get('description', '')
    if description and len(description.split()) < 20:
        validation_result['warnings'].append("Job description could be more detailed")
    
    # Experience level validation
    experience = job_data.get('experience_level', '')
    if not experience:
        validation_result['suggestions'].append("Consider specifying experience level for better candidate matching")
    
    return validation_result