Sure. Here’s a detailed **README.md** tailored for your multi-agent Agentic RAG system with local PDF retrieval, ranking, and Streamlit UI.

---

```markdown
# Agentic RAG Multi-Agent System

A proof-of-concept multi-agent Retrieval-Augmented Generation (RAG) system designed to assist HR teams in searching, ranking, and interviewing AI/ML talent using local document corpora (PDF resumes and related docs).

---

## Features

- **Multi-Agent Architecture:**  
  Modular agents handle query planning, rewriting, document retrieval, candidate ranking, memory management, and answer quality control.

- **Local PDF Corpus Search:**  
  Uses vector embeddings and FAISS similarity search for efficient retrieval of relevant PDF pages from local `docs/` folder.

- **Candidate Ranking:**  
  Extracts skills and experience from retrieved documents and ranks candidates based on query relevance and geographic location.

- **Conversation Memory:**  
  Stores chat history persistently in SQLite (`memory1.db`) to provide contextual continuity.

- **Streamlit UI:**  
  Interactive chat interface for HR users to submit queries, see ranked candidates, and receive interview question suggestions.

- **Quality Check Agent:**  
  Ensures final responses contain accurate inline citations referencing source documents.

---

## Project Structure

```

ai\_rag\_multi\_agent/
│
├── agents/
│   ├── planner.py          # Generates execution plans from user queries
│   ├── rewriter.py         # Refines user queries
│   ├── search.py           # Retrieves relevant PDF pages using vector similarity
│   ├── ranking.py          # Ranks candidate profiles based on skills and location
│   ├── memory.py           # Handles conversation history in SQLite
│   ├── quality.py          # Verifies citations and answer quality
│   └── response.py         # Generates final answer output
│
├── utils/
│   ├── pdf\_loader.py       # Loads and embeds PDF documents
│   └── helpers.py          # Utility functions
│
├── docs/                   # Local PDF resumes and related documents
├── fetched\_data/           # Cached fetched results from searches
├── memory1.db              # SQLite DB file created at runtime
├── main.py                 # Streamlit app and orchestrator entry point
├── requirements.txt        # Python dependencies
└── README.md               # This file

````

---

## Setup & Installation

1. Clone this repo and `cd` into it:
    ```bash
    git clone <repo-url>
    cd ai_rag_multi_agent
    ```

2. Create a Python virtual environment (recommended):
    ```bash
    python -m venv venv
    source venv/bin/activate       # macOS/Linux
    venv\Scripts\activate          # Windows PowerShell
    ```

3. Install dependencies:
    ```bash
    pip install -r requirements.txt
    ```

4. Prepare your `docs/` folder:  
   Add your local PDFs (resumes, job descriptions, etc.) here.

5. Set your OpenAI API key or any other LLM API keys (if used) as environment variables, e.g.:

    ```bash
    export OPENAI_API_KEY="your_key_here"
    ```

    Or create a `.env` file and load it in `main.py`.

---

## Running the App

Launch the Streamlit interface with:

```bash
python -m streamlit run main.py
````

This opens a local web UI where you can:

* Enter your hiring queries (e.g., “Find top PyTorch engineers in Dubai”)
* View ranked candidate lists with scores
* Get suggested interview questions tailored to skills
* See the conversational history and source citations

---

## How It Works

* **User Query → PlannerAgent**
  The query is parsed and a plan of tasks is created, e.g., rewrite query, search docs, rank candidates.

* **RewriterAgent**
  Refines the query into concise keywords.

* **SearchAgent**
  Uses vector similarity search over embedded PDF pages to retrieve relevant candidate info.

* **RankingAgent**
  Extracts candidate skills and locations from docs, scores and ranks candidates based on query relevance and geographic proximity.

* **MemoryAgent**
  Stores conversation context in SQLite for continuity.

* **QualityAgent**
  Verifies inline citations against source docs for accuracy.

* **ResponseAgent**
  Aggregates info, formats final responses with citations, and suggests interview questions.

---

## Extending & Customizing

* Replace OpenAI calls with local open-source LLMs if desired (adjust agents accordingly).
* Add more candidate scoring features, e.g., education, certifications.
* Enhance UI with React/Next.js or other frontend frameworks.
* Integrate live web scraping or job board APIs for real-time data.

---

## Troubleshooting

* **Streamlit command not found:**
  Run `python -m streamlit run main.py` instead of just `streamlit run main.py`.

* **SQLite DB errors:**
  Ensure `memory1.db` is writable and schema is initialized by `MemoryAgent`.

* **Embedding failures:**
  Verify your PDF files are text-readable and that required embedding models are installed.

* **API key errors:**
  Confirm environment variables are set correctly and accessible.

---

## License

MIT License © Your Name

---

## Contact

For questions or contributions, open an issue or contact:

* Email: [your.email@example.com](mailto:your.email@example.com)
* GitHub: [https://github.com/yourusername/ai\_rag\_multi\_agent](https://github.com/yourusername/ai_rag_multi_agent)

---

*This project demonstrates a modular multi-agent approach for AI-powered HR talent search, ranking, and interview assistance using local document corpora and language models.*

```

---

If you want, I can also help you generate `requirements.txt` or more detailed setup instructions.
```
