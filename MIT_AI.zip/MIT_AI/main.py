import streamlit as st
import pandas as pd
import plotly.express as px
import plotly.graph_objects as go
from datetime import datetime
import os
import sys

# --- LLM Client class (llama3) ---
class LLMClient:
    def __init__(self, model_name="llama3", temperature=0.3, max_tokens=500):
        self.model_name = model_name
        self.temperature = temperature
        self.max_tokens = max_tokens
        # Initialize your llama3 model or API here

    def generate(self, prompt: str) -> str:
        # Replace with llama3 inference or API call
        # Here we just simulate response:
        return f"Simulated llama3 response to: {prompt}"

# --- RankingAgent ---
class RankingAgent:
    def __init__(self, llm_client=None):
        self.llm = llm_client or LLMClient()

    def rank_candidates(self, job_title, required_skills, experience_level, location, max_results):
        prompt = (
            f"Rank candidates for the job '{job_title}' with skills {required_skills}, "
            f"experience '{experience_level}', and location '{location}'. "
            "Provide a list of candidate dictionaries with keys: name, email, location, experience, skills, skills_score, location_score, total_score."
        )
        response = self.llm.generate(prompt)
        # TODO: parse real response, here mock data:
        mock_candidates = [
            {
                "name": "Alice Johnson",
                "email": "alice.johnson@example.com",
                "location": "New York",
                "experience": 5,
                "skills": required_skills,
                "skills_score": 92,
                "location_score": 85,
                "total_score": 88.5,
            },
            {
                "name": "Bob Smith",
                "email": "bob.smith@example.com",
                "location": "San Francisco",
                "experience": 6,
                "skills": required_skills,
                "skills_score": 90,
                "location_score": 80,
                "total_score": 85,
            },
            {
                "name": "Carol Lee",
                "email": "carol.lee@example.com",
                "location": "Remote",
                "experience": 4,
                "skills": required_skills,
                "skills_score": 88,
                "location_score": 90,
                "total_score": 86,
            },
        ]
        return mock_candidates[:max_results]

# --- PlannerAgent ---
class PlannerAgent:
    def __init__(self, llm_client=None):
        self.llm = llm_client or LLMClient()

    # Add planner logic if needed, currently stub
    def plan(self, query):
        return self.llm.generate(f"Plan for: {query}")

# --- MemoryAgent ---
class MemoryAgent:
    def __init__(self):
        self.history = []

    def add(self, entry):
        self.history.append(entry)

    def get_last(self, n=10):
        return self.history[-n:]

# --- Helpers ---
def generate_interview_questions(job_title, job_skills, candidate_skills):
    # Use LLM or heuristic here; dummy example for demo:
    questions = []
    for skill in candidate_skills:
        if skill.lower() == "pytorch":
            questions.append(
                "Explain how you would optimize training speed in a large PyTorch model."
            )
            questions.append(
                "Describe a challenging bug you fixed in PyTorch and how you approached it."
            )
            questions.append(
                "Design a simple game or interactive task to test PyTorch skills in an interview."
            )
        elif skill.lower() == "tensorflow":
            questions.append(
                "How do you handle model versioning and deployment using TensorFlow?"
            )
            questions.append(
                "Explain eager execution and graph mode in TensorFlow."
            )
        else:
            questions.append(f"Describe your experience with {skill} and its applications.")
    return questions

# --- Streamlit UI setup ---
st.set_page_config(
    page_title="AI-Powered HR Recruitment Dashboard",
    page_icon="🚀",
    layout="wide",
    initial_sidebar_state="expanded"
)

# Custom CSS for modern UI
st.markdown("""
<style>
    .main-header {
        background: linear-gradient(90deg, #667eea 0%, #764ba2 100%);
        padding: 2rem;
        border-radius: 10px;
        color: black;
        text-align: center;
        margin-bottom: 2rem;
    }
    .metric-card {
        background: black;
        padding: 1.5rem;
        border-radius: 10px;
        box-shadow: 0 2px 10px rgba(0,0,0,0.1);
        border-left: 4px solid #667eea;
        margin: 1rem 0;
    }
    .candidate-card {
        background: black;
        padding: 1.5rem;
        border-radius: 10px;
        box-shadow: 0 2px 10px rgba(0,0,0,0.1);
        margin: 1rem 0;
        border-left: 4px solid #28a745;
    }
    .skill-tag {
        display: inline-block;
        background: #667eea;
        color: white;
        padding: 0.3rem 0.6rem;
        border-radius: 15px;
        font-size: 0.8rem;
        margin: 0.2rem;
    }
    .score-high { color: #28a745; font-weight: bold; }
    .score-medium { color: #ffc107; font-weight: bold; }
    .score-low { color: #dc3545; font-weight: bold; }
    .sidebar .sidebar-content {
        background: #f8f9fa;
    }
    .interview-question {
        background: #f8f9fa;
        padding: 1rem;
        border-radius: 8px;
        margin: 0.5rem 0;
        border-left: 3px solid #17a2b8;
    }
</style>
""", unsafe_allow_html=True)

# Initialize session state
if 'rankings' not in st.session_state:
    st.session_state.rankings = []
if 'job_history' not in st.session_state:
    st.session_state.job_history = []

# Initialize agents and LLM client
@st.cache_resource
def init_agents():
    llm_client = LLMClient()
    ranking_agent = RankingAgent(llm_client=llm_client)
    planner_agent = PlannerAgent(llm_client=llm_client)
    memory_agent = MemoryAgent()
    return ranking_agent, planner_agent, memory_agent

ranking_agent, planner_agent, memory_agent = init_agents()

# Sidebar
with st.sidebar:
    st.markdown("## 🎯 Navigation")
    page = st.selectbox(
        "Select Page",
        ["🏠 Dashboard", "🔍 Candidate Search", "📊 Analytics", "⚙️ Settings"]
    )
    
    st.markdown("---")
    st.markdown("## 📈 Quick Stats")
    
    total_candidates = len(st.session_state.rankings) if st.session_state.rankings else 0
    st.metric("Total Candidates", total_candidates)
    st.metric("Jobs Posted", len(st.session_state.job_history))
    st.metric("Active Searches", 1 if st.session_state.rankings else 0)

# Main content based on selected page
if page == "🏠 Dashboard":
    st.markdown("""
    <div class="main-header">
        <h1>🚀 AI-Powered HR Recruitment Dashboard</h1>
        <p>Intelligent candidate ranking and interview preparation system</p>
    </div>
    """, unsafe_allow_html=True)
    
    st.markdown("## 💼 Create New Job Search")
    col1, col2, col3 = st.columns([2, 1, 1])
    
    with col1:
        job_title = st.text_input("Job Title", placeholder="e.g., Senior AI Engineer")
        job_description = st.text_area(
            "Job Description",
            placeholder="Describe the role, responsibilities, and requirements...",
            height=100
        )
    with col2:
        required_skills = st.multiselect(
            "Required Skills",
            options=[
                "Python", "PyTorch", "TensorFlow", "Scikit-learn", "Keras",
                "OpenCV", "NLTK", "spaCy", "Transformers", "LangChain",
                "MLflow", "Docker", "Kubernetes", "AWS", "Azure", "GCP",
                "SQL", "MongoDB", "React", "Node.js", "FastAPI", "Django"
            ]
        )
        
        experience_level = st.selectbox(
            "Experience Level",
            ["Junior (0-2 years)", "Mid (2-5 years)", "Senior (5+ years)", "Lead (8+ years)"]
        )
    with col3:
        preferred_location = st.selectbox(
            "Preferred Location",
            ["Remote", "New York", "San Francisco", "London", "Berlin", "Singapore", "Any"]
        )
        
        max_candidates = st.slider("Max Candidates to Show", 3, 20, 5)
    
    if st.button("🔍 Search Candidates", type="primary", use_container_width=True):
        if job_title and required_skills:
            with st.spinner("🤖 AI agents are analyzing candidates..."):
                rankings = ranking_agent.rank_candidates(
                    job_title=job_title,
                    required_skills=required_skills,
                    experience_level=experience_level,
                    location=preferred_location,
                    max_results=max_candidates
                )
                st.session_state.rankings = rankings
                st.session_state.current_job = {
                    'title': job_title,
                    'skills': required_skills,
                    'experience': experience_level,
                    'location': preferred_location,
                    'timestamp': datetime.now()
                }
                st.session_state.job_history.append(st.session_state.current_job)
            st.success(f"✅ Found {len(rankings)} matching candidates!")
        else:
            st.error("Please fill in job title and select at least one required skill.")
    
    if st.session_state.rankings:
        st.markdown("---")
        st.markdown("## 🏆 Top Candidates")
        
        col1, col2, col3, col4 = st.columns(4)
        
        scores = [c['total_score'] for c in st.session_state.rankings]
        with col1:
            st.metric("Avg Score", f"{sum(scores)/len(scores):.1f}")
        with col2:
            st.metric("Top Score", f"{max(scores):.1f}")
        with col3:
            st.metric("Score Range", f"{max(scores) - min(scores):.1f}")
        with col4:
            locations = [c['location'] for c in st.session_state.rankings]
            st.metric("Locations", len(set(locations)))
        
        for i, candidate in enumerate(st.session_state.rankings[:max_candidates]):
            with st.expander(f"#{i+1} {candidate['name']} - Score: {candidate['total_score']:.1f}", expanded=i<3):
                col1, col2 = st.columns([2, 1])
                with col1:
                    st.markdown(f"""
                    <div class="candidate-card">
                        <h4>{candidate['name']}</h4>
                        <p><strong>📧 Email:</strong> {candidate['email']}</p>
                        <p><strong>📍 Location:</strong> {candidate['location']}</p>
                        <p><strong>💼 Experience:</strong> {candidate['experience']} years</p>
                        <p><strong>🎯 Skills Match:</strong> {candidate['skills_score']:.1f}/100</p>
                        <p><strong>📍 Location Match:</strong> {candidate['location_score']:.1f}/100</p>
                        <p><strong>📊 Total Score:</strong> {candidate['total_score']:.1f}/100</p>
                    </div>
                    """, unsafe_allow_html=True)
                    st.markdown("**🛠️ Technical Skills:**")
                    skills_html = ""
                    for skill in candidate['skills'][:10]:
                        skills_html += f'<span class="skill-tag">{skill}</span>'
                    st.markdown(skills_html, unsafe_allow_html=True)
                with col2:
                    st.markdown("**💭 Suggested Interview Questions:**")
                    questions = generate_interview_questions(
                        st.session_state.current_job['title'],
                        st.session_state.current_job['skills'],
                        candidate['skills'][:5]
                    )
                    for j, question in enumerate(questions[:3], 1):
                        st.markdown(f"""
                        <div style="
                        background-color: black;
                        color: white;
                        padding: 15px;
                        border-radius: 8px;
                        margin-bottom: 10px;
                        ">
                        <strong>Q{j}:</strong> {question}
                        </div>
                        """, unsafe_allow_html=True)
                    st.button(f"📧 Contact {candidate['name'].split()[0]}", key=f"contact_{i}")
                    st.button(f"⭐ Shortlist", key=f"shortlist_{i}")
                    st.button(f"📋 View Full CV", key=f"cv_{i}")

elif page == "🔍 Candidate Search":
    st.markdown("## 🔍 Advanced Candidate Search")
    with st.expander("🎯 Search Filters", expanded=True):
        col1, col2, col3 = st.columns(3)
        with col1:
            skill_filter = st.multiselect(
                "Filter by Skills",
                ["Python", "PyTorch", "TensorFlow", "React", "Node.js", "AWS", "Docker"]
            )
        with col2:
            experience_filter = st.slider("Minimum Experience (years)", 0, 15, 0)
        with col3:
            location_filter = st.selectbox(
                "Location",
                ["All", "Remote", "New York", "San Francisco", "London"]
            )
    if st.button("Apply Filters"):
        st.info("🔍 Searching candidates with applied filters...")

elif page == "📊 Analytics":
    st.markdown("## 📊 Recruitment Analytics")
    if st.session_state.rankings:
        scores = [c['total_score'] for c in st.session_state.rankings]
        fig_hist = px.histogram(
            x=scores,
            title="Candidate Score Distribution",
            labels={'x': 'Total Score', 'y': 'Number of Candidates'},
            color_discrete_sequence=['#667eea']
        )
        st.plotly_chart(fig_hist, use_container_width=True)

        all_skills = []
        for candidate in st.session_state.rankings:
            all_skills.extend(candidate['skills'][:5])
        skill_counts = pd.Series(all_skills).value_counts().head(10)

        fig_skills = px.bar(
            x=skill_counts.values,
            y=skill_counts.index,
            orientation='h',
            title="Most Common Skills in Candidate Pool",
            labels={'x': 'Frequency', 'y': 'Skills'},
            color_discrete_sequence=['#764ba2']
        )
        fig_skills.update_layout(yaxis={'categoryorder': 'total ascending'})
        st.plotly_chart(fig_skills, use_container_width=True)

        locations = [c['location'] for c in st.session_state.rankings]
        location_counts = pd.Series(locations).value_counts()

        fig_locations = px.pie(
            values=location_counts.values,
            names=location_counts.index,
            title="Candidate Distribution by Location"
        )
        st.plotly_chart(fig_locations, use_container_width=True)
    else:
        st.info("📊 Run a candidate search to see analytics")

elif page == "⚙️ Settings":
    st.markdown("## ⚙️ System Settings")
    st.markdown("### 🛡️ Bias Prevention")
    col1, col2 = st.columns(2)
    with col1:
        st.checkbox("Enable name anonymization", value=True)
        st.checkbox("Remove gender indicators", value=True)
        st.checkbox("Normalize location scoring", value=True)
    with col2:
        st.checkbox("Skills-based ranking only", value=False)
        st.checkbox("Experience normalization", value=True)
        st.checkbox("Diverse candidate promotion", value=True)
    st.markdown("### ⚖️ Scoring Weights")
    skills_weight = st.slider("Skills Weight", 0.0, 1.0, 0.7)
    experience_weight = st.slider("Experience Weight", 0.0, 1.0, 0.2)
    location_weight = st.slider("Location Weight", 0.0, 1.0, 0.1)
    st.markdown("### 🤖 AI Model Configuration")
    model_temperature = st.slider("Model Temperature", 0.0, 1.0, 0.3)
    max_tokens = st.number_input("Max Tokens for Questions", 100, 1000, 500)
    if st.button("Save Settings", type="primary"):
        st.success("✅ Settings saved successfully!")

# Footer
st.markdown("---")
st.markdown("""
<div style="text-align: center; color: #666;">
    <p>🚀 AI-Powered HR Recruitment System | Built with Streamlit</p>
    <p>Ensuring fair, bias-free, and intelligent candidate selection</p>
</div>
""", unsafe_allow_html=True)
